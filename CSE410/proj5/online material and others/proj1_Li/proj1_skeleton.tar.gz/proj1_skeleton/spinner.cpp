#include <cstdlib>
#include <cstdio>
#include <unistd.h>

int main(int argc, char* argv[]){
    while(true)
    {
        //keep spinning...
        sleep(1);
    }
}
