/* 
 * File:   CAquarium.cpp
 * Author: Yaxing Li
 * 
 * Created on September 9, 2013, 5:59 AM
 */
#include "CAquarium.h"
#include "CFishBeta.h"
#include "CFishAngel.h"
#include "CFishBubbles.h"
using namespace std;

const wstring DirectoryContainingImages(L"images/");

/*! \brief Default constructor
 */
CAquarium::CAquarium()
{
    if(!mBackground.LoadFile(L"images/background1.png", wxBITMAP_TYPE_PNG))
        wxMessageBox(L"Failed to open image background1.png");
    
    if(!mTrashcan.LoadFile(L"images/trashcan.png", wxBITMAP_TYPE_PNG))
        wxMessageBox(L"Failed to open image trashcan.png");
      
}
/*! \brief Copy
*/
CAquarium::CAquarium(const CAquarium& orig) {
}

/*! \brief Destructor
 * Deltes the Aquarium and sets its initial size and name
 */
CAquarium::~CAquarium() 
{
    while(!mItems.empty())
    {
        delete mItems.front();
        mItems.pop_front();
    }
}

/*! \brief Draw the aquarium
 * \param dc The device context to draw onto
 */
void CAquarium::OnDraw(wxDC &dc)
{
     dc.DrawBitmap(mBackground, 0, 0);
        
     // Create a font
     wxFont font(12, wxFONTFAMILY_SWISS, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL, false);
     dc.SetFont(font);
     dc.SetTextForeground(wxColour(255, 255, 255));

     dc.DrawText(L"Under the Sea!", 2, 2);
     
     for(list<CItem *>::iterator t=mItems.begin(); t!=mItems.end(); t++)
     {
         CItem *item = *t;
         item->Draw(dc);
     }
     if(mTrashcanActive) 
             dc.DrawBitmap(mTrashcan, 0, 0);
     
}

/*! \brief Get an image from the image cache
 *
 * Given a base name for an image file, determine if
 * we have already loaded it. If we have, return a pointer
 * to the wxBitmap object in the cache. If we have not
 * previously loaded it, load it into the cache and then
 * return a pointer to the image.
 * \param name The base name of the image file. We put images/ onto
 * the front of this because that is where the file is located.
 * \returns Pointer to cached image object or NULL if file not found.
 */
wxImage *CAquarium::GetCachedImage(const std::wstring name)
{
    // See if the name exists in the cache already.
    map<wstring, wxImage>::iterator i = mImageCache.find(name);
    if(i != mImageCache.end())
    {
        // If we got here, it does exist and i->second is a
        // reference to the bitmap object.
        return &i->second;
    }

    // We'll add the path to the name of the file here.
    wstring realname = DirectoryContainingImages + name;

    // Create a bitmap image and load the file into it.
    wxImage bitmap;
    if(!bitmap.LoadFile(realname.c_str()))
    {
         wstring msg = wstring(L"Unable to open image ") + realname;
         wxMessageBox(msg.c_str());
         return NULL;
    }

    // Add it to the cache and return it.
    mImageCache[name] = bitmap;
    return &mImageCache[name];
}

/*! \brief Add an item to the aquarium
 * 
 * This automatically centers the new item in the background image.
 * 
 * \param item New item to add
 */
void CAquarium::AddItem(CItem* item)
{
    item->SetLocation(mBackground.GetWidth()/2, mBackground.GetHeight()/2);
    mItems.push_back(item);
}

/* \brief Determine if the mouse is over Trash Can*/


/*! \brief Test an x,y click location to see if it clicked
 * on some item in the aquarium.
 * \param x X location
 * \param y Y location
 * \returns Pointer item we clicked on or null if none.
 */
CItem *CAquarium::HitTest(int x, int y) 
{
    for(list<CItem *>::reverse_iterator i=mItems.rbegin(); 
            i != mItems.rend();  i++) 
    {
        if((*i)->HitTest(x, y)) 
        {
            return *i;
        }
    }
    return  NULL;
}
/*! \brief Count number of betafish when its requested
 * 
 * \returns The number of beta fish on screen.
 */
int CAquarium::getBeta()
{
    int cnt=0;
    for(list<CItem *>::reverse_iterator i=mItems.rbegin(); 
            i != mItems.rend();  i++) 
    {
        if((*i)->CountBeta())
        {
            cnt++;
        }
    }
    return  cnt;
}

/*! \brief Move the dragged Item to the back of CItem *list
 */
void CAquarium::MoveFront(CItem *item)
{
    mItems.remove(item);
    mItems.push_back(item);
}
/*! \brief Test an x,y click location to see if it the mouse is over Trash
 *  can icon
 * \param x X location
 * \param y Y location
 *  \returns True if the mouse is over Trash can icon.
 */
bool CAquarium::IsOverTrashcan(int x, int y) 
{
    if(!mTrashcanActive) 
    {
        return false;
    }
    return x < 51 && y < 70;
}
/*! \brief Delete Fish when its dragged over Trash Can
 */
void CAquarium::DeleteFish(CItem *item) 
{
    mItems.remove(item);
    delete item;
}

/*! \brief Control the Trash Can
 * Appears when menu option chosen
 * Disappear when menu option clicked again
 */
void CAquarium::mTrashCanControl()
{
    if (mTrashcanActive)
        mTrashcanActive=0;
    else
       mTrashcanActive=1;
}

