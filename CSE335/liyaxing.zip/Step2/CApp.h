/* 
 * File:   CApp.h
 * Author: Yaxing Li
 *
 * Created on September 9, 2013, 4:50 AM
 */

#ifndef CAPP_H
#define	CAPP_H
#include "wx/wx.h"
//! Application main class
class CApp : public wxApp
{
public:
    CApp();
    CApp(const CApp &orig);
    virtual ~CApp();

    virtual bool OnInit();
};
#endif	/* CAPP_H */

