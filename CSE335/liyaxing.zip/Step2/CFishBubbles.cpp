/* 
 * File:   CFishBubbles.cpp
 * Author: Yaxing Li
 * 
 * Created on September 9, 2013, 4:31 PM
 */

#include "CFishBubbles.h"

#include "CAquarium.h"
//! Fish filename 
using namespace std;
const wstring FishBetaImageName(L"bubbles.png");


/*! Constructor
 */
CFishBubbles::CFishBubbles(CAquarium *aquarium) : CItem(aquarium)
{   
    mFishImage = aquarium->GetCachedImage(FishBetaImageName);
    mFishBitmap = new wxBitmap(*mFishImage);
}
//! Destructor
CFishBubbles::~CFishBubbles()
{
    delete mFishBitmap;
}

/*! Draw our fish
 * \param dc A device context to draw the fish on
 */
void CFishBubbles::Draw(wxDC &dc)
{
    int wid = mFishBitmap->GetWidth();
    int hit = mFishBitmap->GetHeight(); 
    dc.DrawBitmap(*mFishBitmap, GetX() - wid/2, GetY() - hit/2, true);
}

/*! \brief Test to see if we hit this object with a mouse.
 * \param x X position to test
 * \param y Y position to test
 * \return true if hit.
 */
bool CFishBubbles::HitTest(int x, int y)
{
    int wid = mFishImage->GetWidth();
    int hit = mFishImage->GetHeight();
    
    // Make x and y relative to the top-left corner of the bitmap image
    // Subtracting the center makes x, y relative to the center of the image.
    // Adding half the size makes x, y relative to the top corner of the image
    x = x - GetX() + wid/2;
    y = y - GetY() + hit/2;

    // Test to see if x, y are in the image
    if(x < 0 || y < 0 || x >= wid || y >= hit)
    {
        // We are outside the image
        return false;
    }

    // Test to see if x, y are in the drawn part of the image
    return !mFishImage->HasAlpha() || mFishImage->GetAlpha(x, y) > 0;
}

