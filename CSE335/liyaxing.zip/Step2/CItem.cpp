/* 
 * File:   CItem.cpp
 * Author: Yaxing Li
 * 
 * Created on September 9, 2013, 6:08 AM
 */

#include "CItem.h"
#include "CAquarium.h"
/*! \brief Constructor
 * \param aquarium The aquarium this item is a member of
 */
CItem::CItem(CAquarium *aquarium) : mAquarium(aquarium), mX(0), mY(0)
{
}

CItem::~CItem() {
}

