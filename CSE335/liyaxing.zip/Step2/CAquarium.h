/* 
 * File:   CAquarium.h
 * Author: Yaxing Li
 *
 * Created on September 9, 2013, 5:59 AM
 */

#ifndef CAQUARIUM_H
#define	CAQUARIUM_H

#include <map>
#include <list>
#include <string>
#include <wx/wx.h>
#include "CItem.h"

class CAquarium
{
public:
    CAquarium();
    CAquarium(const CAquarium& orig);
    virtual ~CAquarium();
    CItem *HitTest(int x, int y);
    void OnDraw(wxDC &dc);    
    wxImage *GetCachedImage(const std::wstring name);
    void DragItemfront(CItem *item);
    void AddItem(CItem *item);
    void MoveFront(CItem *item);
    bool IsOverTrashcan(int x, int y);
    void DeleteFish(CItem *item);
    void mTrashCanControl();    //Control appear/disappear of Trash Can
    int getBeta();              //Count Betafish
private:
    wxBitmap    mBackground;            //!< Background image to use
    wxBitmap    mTrashcan;              //!< Trashcan image to use
    bool mTrashcanActive;               //!< Is the trashcan active
    //! The image cache
    std::map<std::wstring, wxImage> mImageCache;
    //! All of the items that populate our aquarium
    std::list<CItem *> mItems;
};

#endif	/* CAQUARIUM_H */

