/* 
 * File:   CFishAngel.h
 * Author: Yaxing Li
 *
 * Created on September 9, 2013, 4:13 PM
 */

#ifndef CFISHANGEL_H
#define	CFISHANGEL_H
#include "CItem.h"
class CFishAngel :public CItem
{
public:
    CFishAngel(CAquarium *aquarium);
    virtual void Draw(wxDC &dc);
    virtual ~CFishAngel();
    bool HitTest(int x, int y);
private:
   
    //! Default constructor (disabled)
    CFishAngel();

    //! Copy constructor (disabled)
    CFishAngel(const CFishAngel &);
    wxImage *mFishImage;        //!< Pointer to the image of the fish
    wxBitmap *mFishBitmap;      //!< Pointer to a bitmap for the fish
};

#endif	/* CFISHANGEL_H */

