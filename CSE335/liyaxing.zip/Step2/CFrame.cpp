/* 
 * File:   CFrame.cpp
 * Author: Yaxing Li
 * 
 * Created on September 9, 2013, 5:16 AM
 */
using namespace std;
#include <sstream>
#include "CFrame.h"
BEGIN_EVENT_TABLE(CFrame, wxFrame)
        EVT_MENU(ID_Exit, CFrame::OnExit)
        EVT_MENU(ID_Trashcan, CFrame::OnTrashcan)
        EVT_MENU(ID_About, CFrame::OnAbout)
        EVT_MENU(ID_AddFishBeta, CFrame::OnAddFishBeta)
        EVT_MENU(ID_AddFishAngel, CFrame::OnAddFishAngel)
        EVT_MENU(ID_AddFishBubbles, CFrame::OnAddFishBubbles)
        EVT_MENU(ID_CountBeta, CFrame::OnCountBeta)
        EVT_LEFT_DOWN(CFrame::OnLeftButtonDown)
        EVT_PAINT(CFrame::OnPaint)      
        EVT_MOTION(CFrame::OnMouseMove)
        EVT_LEFT_UP(CFrame::OnMouseMove)
END_EVENT_TABLE()

/*! \brief Default constructor
 * 
 * Creates the frame and sets its initial size and name
 */
CFrame::CFrame() : wxFrame( NULL, -1, L"wxWidgets Application", 
                            wxPoint(20, 20), wxSize(1024,800) )
{
//
     // File menu
     //
     mGrabbedItem = NULL;
     wxMenu *menuFile = new wxMenu;
     menuFile->Append(ID_About, L"&About");
     menuFile->AppendSeparator();
     menuFile->Append(ID_CountBeta, L"&Count Beta");
     menuFile->AppendSeparator();
     menuFile->Append(ID_Trashcan, L"&Trash Can");
     menuFile->AppendSeparator();
     wxMenuItem *exitItem = menuFile->Append( ID_Exit, L"E&xit" );
     exitItem->SetHelp(L"Exit the program");
     
     //
     // Fish menu
     //
     wxMenu *menuFish = new wxMenu;
     menuFish->Append(ID_AddFishBeta, L"&Beta");
     menuFish->Append(ID_AddFishAngel, L"&Angel");
     menuFish->Append(ID_AddFishBubbles, L"&Bubbles");
     //
     // Menu Bar
     //

     wxMenuBar *menuBar = new wxMenuBar;
     menuBar->Append( menuFile, L"&File");
     menuBar->Append( menuFish, L"&Add Fish");
     SetMenuBar( menuBar );
     
     CreateStatusBar();
     SetStatusText(L"Status");
     
     SetBackgroundColour(wxColour(0,0,0));
}
/*! \brief copy
 */
CFrame::CFrame(const CFrame& orig) {
}
/*! \brief Destructor
 */
CFrame::~CFrame() {
}

/*! \brief This function is called when an exit menu item is selected.
 *
 * It closes the main window, which ends the program.
 * \param event An object that describes the event.
 */
void CFrame::OnExit(wxCommandEvent& event)
{
    Close(TRUE);
}

/*!  File/About menu option handler
 * \param event  An object that describes the event.
 */ 
void CFrame::OnAbout(wxCommandEvent& event)
{
    wxMessageBox(L"This is a simple wxWidgets application",
                 L"About Step 2",
                  wxOK | wxICON_INFORMATION, this);
}
/*!  File/Count Beta menu option handler
 * \param event  An object that describes the event.
 */ 
void CFrame::OnCountBeta(wxCommandEvent& event)
{
    wstringstream str;
    int cnt = mAquarium.getBeta();
    str << L"There are " << cnt <<L" Beta fish on the screen." <<ends;
    wxMessageBox(str.str().c_str(),
                 L"Astounding Information",
                  wxOK | wxICON_INFORMATION, this);
}
/*!  File/Trash Can menu option handler
 * \param event  An object that describes the event.
 */ 
void CFrame::OnTrashcan(wxCommandEvent& event)
{
        mAquarium.mTrashCanControl();
        Refresh();
}
/*! \brief Function called whenever we need to redraw the window
 *
 * This function is called in response to a drawing message
 * whenever we need to redraw the window on the screen.
 * It is responsible for painting the window.
 * \param event An event associated with the message.
 */
void CFrame::OnPaint(wxPaintEvent &event)
{
    // Create a device context
    wxPaintDC dc(this);

    mAquarium.OnDraw(dc);

    dc.SetPen(wxNullPen);
    dc.SetBrush(wxNullBrush);
    dc.SetFont(wxNullFont);
}

/*! Add Fish/Beta menu option handler
 * \param event  An object that describes the event.
 */ 
void CFrame::OnAddFishBeta(wxCommandEvent& event) 
{
    mAquarium.AddItem(new CFishBeta(&mAquarium));
    Refresh();
}

/*! Add Fish/Angel menu option handler
 * \param event  An object that describes the event.
 */ 
void CFrame::OnAddFishAngel(wxCommandEvent& event) 
{
    mAquarium.AddItem(new CFishAngel(&mAquarium));
    Refresh();
}
/*! Add Fish/Bubbles menu option handler
 * \param event  An object that describes the event.
 */ 
void CFrame::OnAddFishBubbles(wxCommandEvent& event) 
{
    mAquarium.AddItem(new CFishBubbles(&mAquarium));
    Refresh();
}

/*! \brief Move Item  handler
 *
 * This function is called whenever the mouse left 
 * bottom is on an Item and pushed down
 * \param event The mouse event
 */
void CFrame::OnLeftButtonDown(wxMouseEvent &event)
{
   mGrabbedItem = mAquarium.HitTest(event.m_x, event.m_y);
   if(mGrabbedItem != NULL)
    {
         mAquarium.MoveFront(mGrabbedItem);
    }
}

/*! \brief Mouse move handler
 *
 * This function is called whenever the mouse is 
 * moved over the window.
 * \param event The mouse event
 */
void CFrame::OnMouseMove(wxMouseEvent &event)
{
    // See if an item is currently being moved by the mouse
    if(mGrabbedItem != NULL)
    { 
        // If an item is being moved, we only continue to 
        // move it while the left button is down.
        if(event.m_leftDown)
        {
            mGrabbedItem->SetLocation(event.m_x, event.m_y);
        }
        else
        {
            // When the left button is released, we release the
            // item.if its on Trash can, we will delete the item
            if (mAquarium.IsOverTrashcan(event.m_x,event.m_y))
            {
                mAquarium.DeleteFish(mGrabbedItem);
            }
            mGrabbedItem = NULL;
        }

        // Force the screen to redraw
        Refresh();
    } 
}