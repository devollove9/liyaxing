/* 
 * File:   CFishBubbles.h
 * Author: Yaxing Li
 *
 * Created on September 9, 2013, 4:31 PM
 */

#ifndef CFISHBUBBLES_H
#define	CFISHBUBBLES_H
#include "CItem.h"
class CFishBubbles :public CItem
{
public:
    CFishBubbles(CAquarium *aquarium);
    virtual void Draw(wxDC &dc);
    virtual ~CFishBubbles();
    bool HitTest(int x, int y);
private:
   
    //! Default constructor (disabled)
    CFishBubbles();

    //! Copy constructor (disabled)
    CFishBubbles(const CFishBubbles &);
    wxImage *mFishImage;        //!< Pointer to the image of the fish
    wxBitmap *mFishBitmap;      //!< Pointer to a bitmap for the fish
};

#endif	/* CFISHBUBBLES_H */

