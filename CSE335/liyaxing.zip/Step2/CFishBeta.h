/* 
 * File:   CFishBeta.h
 * Author: Yaxing Li
 *
 * Created on September 9, 2013, 8:33 AM
 */

#ifndef CFISHBETA_H
#define	CFISHBETA_H
#include "CItem.h"
class CFishBeta :public CItem
{
public:
    CFishBeta(CAquarium *aquarium);
    virtual void Draw(wxDC &dc);
    virtual ~CFishBeta();
    bool CountBeta();
    bool HitTest(int x, int y);
private:
   
    //! Default constructor (disabled)
    CFishBeta();

    //! Copy constructor (disabled)
    CFishBeta(const CFishBeta &);
    wxImage *mFishImage;        //!< Pointer to the image of the fish
    wxBitmap *mFishBitmap;      //!< Pointer to a bitmap for the fish
};

#endif	/* CFISHBETA_H */

