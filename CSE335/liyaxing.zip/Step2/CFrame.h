/* 
 * File:   CFrame.h
 * Author: Yaxing Li
 *
 * Created on September 9, 2013, 5:16 AM
 */

#ifndef CFRAME_H
#define	CFRAME_H
#include <wx/wx.h>
#include "CAquarium.h"
#include "CFishBeta.h"
#include "CFishAngel.h"
#include "CFishBubbles.h"
#include "CItem.h"
//! Program main display frame
class CFrame : public wxFrame
{
public:
    CFrame();
    CFrame(const CFrame &orig);
    virtual ~CFrame();
    enum Ids {ID_Exit=1, ID_Trashcan, ID_About, ID_CountBeta, ID_AddFishBeta,ID_AddFishAngel,ID_AddFishBubbles};
    void OnExit(wxCommandEvent& event);
    void OnAbout(wxCommandEvent& event);
    void OnTrashcan(wxCommandEvent& event);
    void OnPaint(wxPaintEvent &event);
    void OnAddFishBeta(wxCommandEvent& event);
    void OnAddFishAngel(wxCommandEvent& event);
    void OnAddFishBubbles(wxCommandEvent& event);
    void OnLeftButtonDown(wxMouseEvent &event);
    void OnMouseMove(wxMouseEvent &event);
    void OnCountBeta(wxCommandEvent& event);
    DECLARE_EVENT_TABLE()
    
private:
    //! An object that describes our aquarium
    CAquarium  mAquarium;
    //! Any item we are currently dragging
    CItem     *mGrabbedItem;
};

#endif	/* CFRAME_H */

