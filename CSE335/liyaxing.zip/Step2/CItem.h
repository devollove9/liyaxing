/* 
 * File:   CItem.h
 * Author: Yaxing Li
 *
 * Created on September 9, 2013, 6:08 AM
 */
#ifndef CITEM_H
#define	CITEM_H

#include <wx/wx.h>

class CAquarium;

//! Class for an item that appears in our aquarium
class CItem
{
public:
    virtual ~CItem();
    
    //! Get the x location of the item
    //! \returns X location
    int GetX() const {return mX;}
    
    //! Get the y location of the item
    //! \returns Y location
    int GetY() const {return mY;}
    
    //! Set the item location
    //! \param x X location
    //! \param y Y location
    void SetLocation(int x, int y) {mX = x; mY = y;}
    
    //! Draw this item
    //! \param dc Device context to draw on
    virtual void Draw(wxDC &dc) = 0;
        
    //! Test to see if we clicked on this item
    //! \param x X location
    //! \param y Y location
    //! \returns true if we clicked on the item
    virtual bool HitTest(int x, int y) {return false;}
    virtual bool CountBeta(){return false;}   //Virtual function count Betafish, return ture only a fish is Beta
protected:
    CItem(CAquarium *aquarium);

private:
    //! Default constructor (disabled)
    CItem();

    //! Copy constructor (disabled)
    CItem(const CItem &);
    
    //! The aquarium this item is contained in
    CAquarium   *mAquarium;
    
    // Item location in the aquarium
    int     mX;         //!< X location for the center of the item
    int     mY;         //!< Y location for the center of the item
};

#endif	/* CITEM_H */

