/*! 
 * \file CDocumentObserver.h
 * 
 * Base class for the observer pattern
 * 
 * \author Charles B. Owen
 */

#ifndef CDOCUMENTOBSERVER_H
#define	CDOCUMENTOBSERVER_H

class CDocument;

/*! \brief The Observer pattern base class for
 * an observer.
 */
class CDocumentObserver 
{
public:
    virtual ~CDocumentObserver();
    
    //! \brief This function is called to update any observers
    virtual void UpdateObserver() = 0;

    /*! \brief Get a pointer to the document
     * \returns Pointer to the document object
     */
    CDocument *GetDocument() {return mDocument;}
    
protected:
    CDocumentObserver(CDocument *document);
    
private:
    //! \brief Default Constructor (Disabled)
    CDocumentObserver();
    //! \brief Copy Constructor (Disabled)
    CDocumentObserver(const CDocumentObserver &);
    //! \brief Assignment Operator (Disabled)
    CDocumentObserver &operator=(const CDocumentObserver &);
    
    //! Document we are observing
    CDocument *mDocument;
};

#endif	/* CDOCUMENTOBSERVER_H */

