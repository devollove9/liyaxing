/* 
 * \file CDrawable.h
 * 
 * Class for drawables on the screen.
 * 
 * \author Charles B. Owen
 */

#ifndef CDRAWABLE_H
#define	CDRAWABLE_H

#include <string>
#include <list>
#include "CIterator.h"
#include "CAnimChannelAngle.h"

class CActor;
class CTimeline;

/*! \brief A drawable on the screen
 */
class CDrawable
{
public:  
    virtual ~CDrawable();
    
    void SetRotation(double mRotation);
    double GetRotation() const;
    void SetName(std::wstring mName);
    std::wstring GetName() const;
    void SetPosition(wxPoint mPosition);
    wxPoint GetPosition() const;
    
    virtual void SetKeyframe();
    virtual void GetKeyframe();
    
    virtual void SetActor(CActor *actor);
    
    virtual void SetTimeline(CTimeline *timeline);
    
    /*! \brief Draw this drawable
     * \param dc The device context to draw on
     */
    virtual void Draw(wxDC *dc) = 0;
    void Place(wxPoint offset, double rotate);
    void AddChild(CDrawable *child);
    
    /*! \brief Does a location hit this drawable?
     * \param pos Location to test
     * \returns true if so.
     */
    virtual bool HitTest(wxPoint pos) = 0;
    virtual bool IsMovable();
    void Move(wxPoint delta);
    
    /*! \brief Set the parent of this drawable
     * \param parent Parent pointer
     */
    void SetParent(CDrawable *parent) {mParent = parent;}
    
    /*! \brief Get parent drawable
     * \returns parent drawable
     */
    CDrawable *GetParent() {return mParent;}
    
        friend class ChildIterator;

    //! Iterator for children of a drawable
    class ChildIterator : public CIterator<CDrawable *>
    {
    public:
        /*! Constructor
         * \param drawable The drawable to iterate over
         */
        ChildIterator(CDrawable *drawable) : mDrawable(drawable) {First();}

        //! Set to the first child
        virtual void First() {mIter = mDrawable->mChildren.begin();}

        //! Advance to the next child
        virtual void Next() {mIter++;}

        //! Determine if we are done
        //! \returns true if past end of list of children
        virtual bool IsDone() {return mIter == mDrawable->mChildren.end();}

        //! Get the current child
        //! \returns Pointer to the current child drawable
        virtual CDrawable *Current() {return *mIter;}

    private:
        //! The drawable we are iterating over
        CDrawable *mDrawable;;

        //! The position in the children of the drawable
        std::list<CDrawable *>::iterator mIter;
    };

    /*! Create and return an iterator for the drawables children
     * \returns Iterator
     */
    ChildIterator *GetDrawables() {return new ChildIterator(this);}

protected:
    CDrawable(std::wstring name);
    wxPoint RotatePoint(wxPoint point, double angle);
    
    wxPoint     mPlacedPosition; //!< Position of drawable on the screen
    double      mPlacedR;        //!< Rotation of the drawable on the screen
    
private:
    //! \brief Default constructor (disabled)
    CDrawable();

    //! \brief Copy constructor (disabled)
    CDrawable(const CDrawable &);

    //! \brief Assignment operator (disabled)
    CDrawable &operator=(const CDrawable &);
    
    
    wxPoint     mPosition;      //!< Position of this drawable
    std::wstring  mName;        //!< Name of this drawable
    double      mRotation;      //!< Current rotation angle in degrees 
    
    //! The actor using this drawable
    CActor *mActor;
    
    CDrawable *mParent;         //!< Parent of this drawable
    
    //! Children of this drawable
    std::list<CDrawable *> mChildren;
    
    //! The animation channel for animating the angle of this drawable
    CAnimChannelAngle mChannel;
};

#endif	/* CDRAWABLE_H */

