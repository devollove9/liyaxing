/* 
 * \file CActor.cpp
 * \author Charles B. Owen
 */

#include "wx/prec.h"
#include "CActor.h"
#include "CDocument.h"

using namespace std;

/*! \brief Constructor
 * \param name The name of the actor
 */
CActor::CActor(const std::wstring &name) : mName(name)
{
    SetName(name);
    mEnabled = true;
    mPosition = wxPoint(0, 0);
    mClickable = true;
    mRoot = NULL;
    mDocument = NULL;
}

//! \brief Destructor
CActor::~CActor()
{
    delete mRoot;
}

/*! \brief Set the root drawable
 * \param root The root drawable
 */
void CActor::SetRoot(CDrawable *root)
{
    mRoot = root;
}

/*! \brief Draw this drawable item
 * \param dc The device context to draw on
 */
void CActor::Draw(wxDC *dc)
{
    // Don't draw if not enabled
    if(!mEnabled)
        return;

    // This takes care of determining the absolute placement
    // of all of the child drawables. We have to determine this 
    // in tree order, which may not be the order we draw.
    if(mRoot)
        mRoot->Place(mPosition, 0);

    for(list<CDrawable *>::iterator d=mDrawablesInOrder.begin(); d!=mDrawablesInOrder.end(); d++)
    {
        CDrawable *drawable = *d;
        drawable->Draw(dc);
    }
}

/*! \brief Test to see if pos hits this drawable
 * \param pos Position to test
 * \returns True if pos is on the actor
 */
CDrawable *CActor::HitTest(wxPoint pos)
{
    // If not enabled or not clickable, we indicate no hit.
    if(!mClickable || !mEnabled)
        return NULL;

    // Since this list is in drawing order, we realy want to know the last thing drawn
    // under the mouse, since it will be on top. So, we reverse iterate over the list.
    for(list<CDrawable *>::reverse_iterator d=mDrawablesInOrder.rbegin(); d!=mDrawablesInOrder.rend(); d++)
    {
        CDrawable *drawable = *d;
        if(drawable->HitTest(pos))
            return *d;
    }

    return NULL;
}

/*! \brief Add a drawable child to this drawable
 * \param drawable The new child
 */
void CActor::AddDrawable(CDrawable *drawable)
{
    mDrawablesInOrder.push_back(drawable);
    drawable->SetActor(this);
}

/*! \brief Set the clickable status
 * \param mClickable New value for the clickable status
 */
void CActor::SetClickable(bool mClickable)
{
    this->mClickable = mClickable;
}

/*! \brief Get the clickable status
 * \returns the clickable status
 */
bool CActor::IsClickable() const
{
    return mClickable;
}

/*! \brief Set a new actor position
 * \param mPosition New value for a new actor position
 */
void CActor::SetPosition(wxPoint mPosition)
{
    this->mPosition = mPosition;
}

/*! \brief Get the actor position
 * \returns the actor position
 */
wxPoint CActor::GetPosition() const
{
    return mPosition;
}

/*! \brief Set the enabled status for the actor
 * \param mEnabled New value for the enabled status for the actor
 */
void CActor::SetEnabled(bool mEnabled)
{
    this->mEnabled = mEnabled;
}

/*! \brief Get the enabled status
 * \returns the enabled status
 */
bool CActor::IsEnabled() const
{
    return mEnabled;
}

/*! \brief Set the actor name
 * \param name The name to set
 */
void CActor::SetName(std::wstring name)
{
    this->mName = name;
    mChannel.SetName(name + L":position");
}

/*! \brief Get The actor name
 * \returns The actor name
 */
std::wstring CActor::GetName() const
{
    return mName;
}


/*! \brief Set the document link for this actor.
 *
 * This is telling the actor what
 * document to use.
 *
 * Also tells all child drawables what the timeline is.
 * \param document The document we are using.
 */
void CActor::SetDocument(CDocument *document)
{
    mDocument = document;

    // Add the animation channel to the timeline
    mDocument->GetTimeline()->AddChannel(&mChannel);
    
    // Set the timeline for all drawables. This links the channels to
    // the timeline system.
    for(list<CDrawable *>::iterator d=mDrawablesInOrder.begin(); d!=mDrawablesInOrder.end(); d++)
    {
        CDrawable *drawable = *d;
        drawable->SetTimeline(mDocument->GetTimeline());
    }
}

/*! \brief Set a keyframe on an actor.
 */
void CActor::SetKeyframe()
{
    mChannel.SetKeyframe(mPosition);
    
    for(list<CDrawable *>::iterator d=mDrawablesInOrder.begin(); d!=mDrawablesInOrder.end(); d++)
    {
        CDrawable *drawable = *d;
        drawable->SetKeyframe();
    }
}

/*! brief Get a keyframe for an actor.
 */
void CActor::GetKeyframe()
{
    if(mChannel.GetNumKeyframes() > 0)
        mPosition = mChannel.GetPoint();
        
    for(list<CDrawable *>::iterator d=mDrawablesInOrder.begin(); d!=mDrawablesInOrder.end(); d++)
    {
        CDrawable *drawable = *d;
        drawable->GetKeyframe();
    }
}