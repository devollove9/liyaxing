/*!
 * \file CHeadTop.h
 * 
 * Implements the top of a characters head, which has special
 * functionality.
 * 
 * \author Charles B. Owen
 * 
 * \brief 
 */

#ifndef CHEADTOP_H
#define CHEADTOP_H

#include "CImageDrawable.h"
#include "CAnimChannelPoint.h"

/*! \brief Implements the top of a characters head, which has special
 * functionality.
 */
class CHeadTop : public CImageDrawable
{
public:
    CHeadTop(const std::wstring &name, const std::wstring &filename);
    virtual ~CHeadTop();
    
    //! \brief Is this drawable moveable?
    //! \returns true
    virtual bool IsMovable() {return true;}
    
    virtual void Draw(wxDC *dc);
    
    /*! \brief Set the location for the center of the eyes
     * \param center New eyes center location
     */
    void SetEyesCenter(wxPoint center) {mEyesCenter = center;}
    
    /*! \brief Get the eyes center location
     * \returns Eyes center location
     */
    wxPoint GetEyesCenter() const {return mEyesCenter;}
    
    /*! \brief Set the distance between the eyes
     * \param d Distance between the eyes in pixels
     */
    void SetInterocularDistance(int d) {mInterocularDistance = d;}
    
    /*! \brief Get the distance between the eyes
     * \returns Distance between the eyes in pixels
     */
    int GetInterocularDistance() const {return mInterocularDistance;}
    
     /*! \brief Get a pointer to the left eye bitmap
     * \returns Pointers to the left eye bitmap
     */
    CRotatedBitmap *GetLeftEye() {return &mLeftEye;}
    
    /*! \brief Get a pointer to the left eye bitmap
     * \returns Pointers to the left eye bitmap
     */
    CRotatedBitmap *GetRightEye() {return &mRightEye;}
    
    virtual void SetTimeline(CTimeline *timeline);
    virtual void SetKeyframe();
    virtual void GetKeyframe();
    virtual void SetActor(CActor *actor);
    
private:
    //! \brief Default constructor (disabled)
    CHeadTop();
    //! \brief Copy constructor (disabled)
    CHeadTop(const CHeadTop &);
    //! \brief Assignment operator (disabled)
    CHeadTop &operator=(const CHeadTop &);

    wxPoint TransformPoint(wxPoint p);
    void DrawTransformedLine(wxDC *dc, int x1, int y1, int x2, int y2);
    void DrawTransformedEllipse(wxDC *dc, int x, int y, int w, int h);
    
    wxPoint mEyesCenter;            //!< Location of the center of the eyes
    int mInterocularDistance;       //!< Distance between the eyes in pixels

    CRotatedBitmap mLeftEye;        //!< Bitmap for the left eye
    CRotatedBitmap mRightEye;       //!< Bitmap for the right eye
    
    //! Animation channel for head position
    CAnimChannelPoint mPositionChannel;
};

#endif    /* CHEADTOP_H */
