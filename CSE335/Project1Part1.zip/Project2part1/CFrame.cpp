/*!
 * \file CFrame.cpp
 *
 * \author Charles B. Owen
 */

#include "wx/prec.h"
#include <string>
#include "CFrame.h"
#include "CDocument.h"
#include "CDocumentFactory.h"
#include "CTimelineDlg.h"
#include "CTextBubbleDrawable.h"

using namespace std;

BEGIN_EVENT_TABLE(CFrame, wxFrame)
    EVT_MENU(ID_Exit, CFrame::OnExit)
    EVT_MENU(ID_About, CFrame::OnAbout)
    EVT_MENU(ID_Move, CFrame::OnMove)
    EVT_MENU(ID_Rotate, CFrame::OnRotate)
    EVT_MENU(ID_Keyframe, CFrame::OnKeyframeSet)
    EVT_MENU(ID_NoKeyframe, CFrame::OnKeyframeClear)
    EVT_MENU(ID_AnimationProperties, CFrame::OnAnimationProperties)
    EVT_MENU(ID_FileSaveAs, CFrame::OnFileSaveAs)
    EVT_MENU(ID_FileOpen, CFrame::OnFileOpen)
    EVT_MENU(ID_TextBubbleHarold, CFrame::OnTextBubbleHarold)
    EVT_MENU(ID_TextBubbleSparty, CFrame::OnTextBubbleSparty)
    EVT_MENU(ID_Play, CFrame::OnPlayPlay)
    EVT_MENU(ID_PlayBeginning, CFrame::OnPlayPlayBeginning)
    EVT_MENU(ID_PlayStop, CFrame::OnPlayStop)
    EVT_TIMER(ID_Timer, CFrame::OnTimer)
END_EVENT_TABLE()

/*! \brief Constructor for our frame.
 */
CFrame::CFrame() : wxFrame( NULL, -1, L"The Canadian Experience",
                            wxPoint(100, 100), wxDefaultSize), mTimer(this, ID_Timer)
{
    //
    // Create the document
    //
    
    // Create our document
    CDocumentFactory factory;
    mDocument = factory.Create();
    mHaroldBubble = factory.GetHaroldBubble();
    mSpartyBubble = factory.GetSpartyBubble();
    
    // This is the default mode for the toolbar and menus
    mMode = ID_Move;

    mPlaying = false;
    
    //
    // File menu
    //
    wxMenu *menuFile = new wxMenu;

    menuFile->Append(ID_FileOpen, L"&Open");
    menuFile->Append(ID_FileSaveAs, L"Save &As...");
    
    menuFile->Append(ID_About, L"&About", L"About this program");
    menuFile->AppendSeparator();
    menuFile->Append( ID_Exit, L"E&xit", L"Exit the program");
    
    //
    // Edit menu
    //
    wxMenu *menuEdit = new wxMenu;
    
    mEditMove = menuEdit->AppendCheckItem(ID_Move, L"&Move", L"Set moving");
    mEditRotate = menuEdit->AppendCheckItem(ID_Rotate, L"&Rotate", "Set rotating");
    
    //
    // Record menu
    //
    wxMenu *menuRecord = new wxMenu;
    
    menuRecord->Append(ID_Keyframe, L"&Set Keyframe", L"Set a keyframe at this time");
    menuRecord->Append(ID_NoKeyframe, L"&Clear Keyframe", L"Clear a keyframe at this time");
    
    //
    // Text bubbles
    //
    wxMenu *menuTextBubbles = new wxMenu;
    menuTextBubbles->Append(ID_TextBubbleHarold, L"&Harold text bubble", L"Change Harold text bubble");
    menuTextBubbles->Append(ID_TextBubbleSparty, L"&Sparty text bubble", L"Change Sparty text bubble");

    //
    // Animation Menu
    //
    wxMenu *menuAnimation = new wxMenu;
    
    menuAnimation->Append(ID_AnimationProperties, L"&Properties", L"Set the animation clip properties");
    
    
    //
    // Play Menu
    //
    wxMenu *menuPlay = new wxMenu;
    menuPlay->Append(ID_Play, L"&Play", L"Play animation starting at current location");
    menuPlay->Append(ID_PlayBeginning, L"Play from &Beginning", L"Play animation starting at beginning");
    menuPlay->Append(ID_PlayStop, L"Stop playing", L"Stop playing animation");
    
    //
    // Menu Bar
    //
    wxMenuBar *menuBar = new wxMenuBar;
    menuBar->Append( menuFile, L"&File");
    menuBar->Append( menuEdit, L"&Edit");
    menuBar->Append( menuAnimation, L"&Animation");
    menuBar->Append( menuRecord, L"&Record");
    menuBar->Append( menuTextBubbles, L"&Bubbles");
    menuBar->Append( menuPlay, L"&Play");
    
    SetMenuBar( menuBar );

    //
    // Create a status bar
    //
    CreateStatusBar();
    SetStatusText(L"");

    //
    // Create a toolbar
    //
    CreateToolBar(wxHORIZONTAL, ID_ToolBar);
    mToolBar = GetToolBar();

    mToolBar->SetMargins(0, 0);
    AddToToolbar(mToolBar, true, L"images/tb_move.png", ID_Move, L"Move");
    AddToToolbar(mToolBar, true, L"images/tb_rotate.png", ID_Rotate, L"Rotate");
    AddToToolbar(mToolBar, false, L"images/tb_keyframe.png", ID_Keyframe, L"Set Keyframe");
    AddToToolbar(mToolBar, false, L"images/tb_nokeyframe.png", ID_NoKeyframe, L"Clear Keyframe");
    
    //
    // Create the child windows
    //

    mViewEdit = new CViewEdit(this);
    mViewActors = new CViewActors(this);
    mViewTimeline = new CViewTimeline(this);
    
    //
    // Create the sizers
    //

    // A vertical sizer so we an put two windows on top of each other
    wxBoxSizer *vertSizer = new wxBoxSizer(wxVERTICAL);
    wxBoxSizer *horzSizer = new wxBoxSizer(wxHORIZONTAL);
    
    horzSizer->Add(mViewActors, 0, wxEXPAND | wxALL, 0);   // Add actors view as first in horzSizer
    horzSizer->Add(mViewEdit, 1, wxEXPAND | wxALL, 0);     // Add edit view as second in horzSizer

    vertSizer->Add(horzSizer, 1, wxEXPAND | wxALL);        // horzSizer is first (top) in vertSizer
    vertSizer->Add(mViewTimeline, 0, wxEXPAND | wxALL, 0); // Add timeline view as second in vertSizer

    SetSizer(vertSizer);
    vertSizer->Fit(this);
    mViewEdit->SetMinSize(wxSize(100, 100));
    
    SetInterface();
}


/*! \brief CFrame destructor. Destroys anything this class owns.
 */
CFrame::~CFrame()
{
    DestroyChildren();
    delete mDocument;
}


/*! \brief Handle the File/Open menu option.
 * \param event The command event for the menu option
 */
void CFrame::OnFileOpen(wxCommandEvent &event)
{
    wxFileDialog dlg(this, L"Open File", L"", L"", L"*.canim", wxFD_OPEN | wxFD_FILE_MUST_EXIST);
    if(dlg.ShowModal() != wxID_OK)
        return;

    wstring filename = dlg.GetPath().wc_str();

    mDocument->LoadAnimation(filename);
}


/*! \brief Called when the File/Save As... menu option is selected.
 * \param event The command event for the menu option
 */
void CFrame::OnFileSaveAs(wxCommandEvent &event)
{
    wxFileDialog dlg(this, L"Save File", L"", L"", L"*.canim", wxFD_SAVE | wxFD_OVERWRITE_PROMPT);
    if(dlg.ShowModal() != wxID_OK)
        return;

    // Get the filename into a local string
    wstring filename = dlg.GetPath().wc_str();

    // If no suffix is supplied for the file, supply it here
    wstring suffix(L".canim");
    if(!equal(suffix.rbegin(), suffix.rend(), filename.rbegin()))
    {
        filename += suffix;
    }

    mDocument->SaveAnimation(filename);
}



/*! \brief Handle Harold text bubble dialog box request
 *
 * \param event The menu event
 */
void CFrame::OnTextBubbleHarold(wxCommandEvent &event)
{
    mHaroldBubble->DialogBox(this);
    GetDocument()->UpdateObservers(); 
}

/*! \brief Handle Sparty text bubble dialog box request
 *
 * \param event The menu event
 */
void CFrame::OnTextBubbleSparty(wxCommandEvent &event)
{
    mSpartyBubble->DialogBox(this);
    GetDocument()->UpdateObservers();
}
    
    


/*! \brief Add a bitmap to the toolbar.
 * \param toolBar the toolbar we are adding to.
 * \param checked true if we use a checked item (stays pressed).
 * \param file Filename for the toolbar icon
 * \param id An id for this toolbar button
 * \param name Associated tool name for tooltip.
 */
void CFrame::AddToToolbar(wxToolBar *toolBar, bool checked, const std::wstring &file, int id, const std::wstring &name)
{
    // It is okay to create this as a local variable, because the
    // system actually copies the bitmap to the toolbar, so it's not
    // referred to later.
    wxBitmap bitmap(file.c_str(), wxBITMAP_TYPE_PNG);
    if(checked)
    {
        toolBar->AddCheckTool(id, L"", bitmap, wxNullBitmap, name.c_str());
    }
    else
    {
        toolBar->AddTool(id, L"", bitmap, name.c_str());
    }
}



/*! \brief Set user interface features
 * 
 * This function sets the status of menu checks marks and active
 * toolbar items.
 */
void CFrame::SetInterface()
{
    mToolBar->ToggleTool(ID_Move, mMode == ID_Move);
    mToolBar->ToggleTool(ID_Rotate, mMode == ID_Rotate);
    mEditMove->Check(mMode == ID_Move);
    mEditRotate->Check(mMode == ID_Rotate);
}


/*! \brief Handle a press of the Move button on the toolbar
 * \param event The command event
 */
void CFrame::OnMove(wxCommandEvent& event)
{
    mMode = ID_Move;
    SetInterface();
}


/*! \brief Handle a press of the rotate button on the toolbar
 * \param event The command event
 */
void CFrame::OnRotate(wxCommandEvent& event)
{
    mMode = ID_Rotate;
    SetInterface();
}


/*! \brief Handle a press of the keyframe set button on the toolbar
 * \param event The command event
 */
void CFrame::OnKeyframeSet(wxCommandEvent& event)
{
    CIteratorPtr<CActor *> iter = GetDocument()->GetActors();
    for(iter->First();  !iter->IsDone();  iter->Next())
    {
        CActor *actor = iter->Current();
        actor->SetKeyframe();
    }
}

/*! \brief Handle a press of the keyframe clear button on the toolbar
 * \param event The command event
 */
void CFrame::OnKeyframeClear(wxCommandEvent& event)
{
    GetDocument()->GetTimeline()->ClearKeyframe();
    GetDocument()->SetAnimationTime(GetDocument()->GetAnimationTime());
}


/*! \brief This function is called when an exit menu item is selected.
 *
 * It closes the main window, which ends the program.
 * \param event An object that describes the event.
 */
void CFrame::OnExit(wxCommandEvent& event)
{
    Close(TRUE);
}


/*! \brief Menu handler for File/About menu option
 * \param event The menu event
 */
void CFrame::OnAbout(wxCommandEvent& event)
{
    wxMessageBox(L"The Canadian Experience is a Dr. Owen Production",
                 L"About the Canadian Experience",
                  wxOK | wxICON_INFORMATION, this);
}


/*! \brief Menu handler for Animation/Properties menu option
 * \param event The menu event
 */
void CFrame::OnAnimationProperties(wxCommandEvent& event)
{
    CTimelineDlg dlg(this, GetDocument()->GetTimeline());
    if(dlg.ShowModal() == wxOK)
    {
        GetDocument()->UpdateObservers();
    }
}


/*! \brief Handle a timer event
 * \param event The timer event
 */
void CFrame::OnTimer(wxTimerEvent &event)
{
    double newTime = mWatch.Time() * 0.001 + mPlayStartTime;
    if(newTime >= mDocument->GetTimeline()->GetDuration())
    {
        newTime = mDocument->GetTimeline()->GetDuration();
        mDocument->SetAnimationTime(newTime);
        mWatch.Pause();
        mTimer.Stop();
        mPlaying = false;
        return;
    }

    mDocument->SetAnimationTime(newTime);
}


/*! \brief Handle the Play>Play menu option
 *
 * \param event The menu event
 */
void CFrame::OnPlayPlay(wxCommandEvent &event)
{
    mWatch.Start();
    mTimer.Start(30);
    mPlaying = true;
    mPlayStartTime = mDocument->GetAnimationTime();
}

/*! \brief Handle the Play>Play from Beginning menu option
 *
 * \param event The menu event
 */
void CFrame::OnPlayPlayBeginning(wxCommandEvent &event)
{
    mWatch.Start();
    mTimer.Start(30);
    mPlaying = true;
    mPlayStartTime = 0;
}

/*! \brief Handle the Play>Stop menu option
 *
 * \param event The menu event
 */
void CFrame::OnPlayStop(wxCommandEvent &event)
{
    if(mPlaying)
    {
        mWatch.Pause();
        mTimer.Stop();
        mPlaying = false;
    }
}
    
    
