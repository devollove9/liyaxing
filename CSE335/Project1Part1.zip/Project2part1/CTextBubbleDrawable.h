/*!
 * \file CTextBubbleDrawable.h
 *
 * Adapter class the implements a text bubble
 *
 * \author Charles B. Owen
 */

#pragma once
#ifndef CTEXTBUBBLEDRAWABLE_H_
#define CTEXTBUBBLEDRAWABLE_H_

#include "CDrawable.h"
#include "CTextBubble.h"
#include "CAnimChannelPoint.h"
#include "CAnimChannelText.h"

/*! \brief Implement a text bubble.
 * 
 * Class the implements a text bubble as a drawable
 * in our animation system.
 */
class CTextBubbleDrawable: public CDrawable, private CTextBubble
{
public:
    CTextBubbleDrawable(const std::wstring &name);
    virtual ~CTextBubbleDrawable();

    virtual void Draw(wxDC *dc);
    virtual bool HitTest(wxPoint pos);
    
    /**
     * \brief Text bubbles are moveable
     * @return true
     */
    virtual bool IsMovable() {return true;}
    
    void DialogBox(wxWindow *window);
    
    virtual void SetTimeline(CTimeline *timeline);
    virtual void SetKeyframe();
    virtual void GetKeyframe();
    virtual void SetActor(CActor *actor);

private:
    //! Disabled
    CTextBubbleDrawable();
    //! Disabled
    CTextBubbleDrawable(CTextBubbleDrawable &);
    
    //! The position channel
    CAnimChannelPoint mPositionChannel;
    
    //! The text channel
    CAnimChannelText mTextChannel;
};

#endif /* CTEXTBUBBLEDRAWABLE_H_ */


