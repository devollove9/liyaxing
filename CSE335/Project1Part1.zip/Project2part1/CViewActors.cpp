/*!
 * \file CViewActors.cpp
 *
 * \author Charles B. Owen
 */

#include "wx/prec.h"
#include "CViewActors.h"
#include "CFrame.h"

BEGIN_EVENT_TABLE(CViewActors, wxScrolledWindow)
    EVT_PAINT(CViewActors::OnPaint)
    EVT_LEFT_DOWN(CViewActors::OnLeftButtonDown)
END_EVENT_TABLE()

/*! \brief Constructor for the actor view.
 * \param frame Frame this window is a child of.
 */
CViewActors::CViewActors(CFrame *frame) :
    wxScrolledWindow(frame, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxVSCROLL | wxBORDER_SUNKEN),
        CDocumentObserver(frame->GetDocument()),
        mFrame(frame)
{
    // This will determine the size. Only the horizontal part matters
    // The sizer will take care of the vertical part for us
    SetMinSize(wxSize(150, 100));
    SetBackgroundColour(wxColour(255, 255, 255));
    SetName(L"ViewActors");
    mTextHeight = 0;
}

/*! \brief The view destructor.
 */
CViewActors::~CViewActors()
{

}

/*! \brief Force an update of this window when the document changes.
 */
void CViewActors::UpdateObserver()
{
    Refresh();
}


/*! \brief Handle a draw request for this window.
 * \param event The draw event
 */
void CViewActors::OnPaint(wxPaintEvent &event)
{
    // Create a device context
    wxPaintDC dc(this);

    // Offset the device context due to any scrolling
    DoPrepareDC(dc);

    // Create the font
    wxFont font(12, wxFONTFAMILY_SWISS, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL);

    wxCoord w, h;
    dc.GetTextExtent(L"TEST", &w, &h);
    mTextHeight = h;
    
    // Y location to draw at
    int y = 0;

    CIteratorPtr<CActor *> iter = GetDocument()->GetActors();
    for(iter->First();  !iter->IsDone();  iter->Next())
    {
        // Get a pointer to this actor
        CActor *actor = iter->Current();
        dc.SetFont(font);
        
        // Set the color to black
        dc.SetTextForeground(wxColour(0, 0, 0));
        
        dc.DrawText(actor->GetName().c_str(), 0, y);
        y += mTextHeight;
        
        
        y += DrawDrawablesNames(&dc, actor->GetRoot(), 0, y);
    }


    dc.SetPen(wxNullPen);
    dc.SetBrush(wxNullBrush);
    dc.SetFont(wxNullFont);
    
    SetVirtualSize(wxSize(150, y));
}


/*! \brief Draw the name of a drawable and the names of all of the
 * drawables children.
 * \param dc The device context
 * \param drawable Pointer to the drawable to draw
 * \param x The x location to draw the text (left to right)
 * \param y The y location to draw the text (top to bottom)
 * \returns The height of all text drawn.
 */
int CViewActors::DrawDrawablesNames(wxDC *dc, CDrawable *drawable, int x, int y)
{
    // Don't draw if no drawable
    if(drawable == NULL)
        return 0;

    // Keep track of the height of what we are drawing
    int height = 0;

    // Indent 10 pixels from the parent
    x += 10;

    // Set the color to blue
    dc->SetTextForeground(wxColour(0, 0, 128));
       
    // Draw the name of the drawable
    dc->DrawText( drawable->GetName().c_str(), x, y);
    height += mTextHeight;
    
    CIteratorPtr<CDrawable *> iter = drawable->GetDrawables();
    for(iter->First();  !iter->IsDone();  iter->Next())
    {
        CDrawable *drawable = iter->Current();

        height += DrawDrawablesNames(dc, drawable, x, y + height);
    }

    return height;
}



/*! \brief Handle a left mouse button press.
 * \param event The command event
 */
void CViewActors::OnLeftButtonDown(wxMouseEvent &event)
{
    // Get the view point start and add to the mouse position
    // to determine where we clicked in the scrolled area.
    int x, y;
    GetViewStart(&x, &y);
    x += event.m_x;
    y += event.m_y;

        GetDocument()->UpdateObservers();
        
    //
    // To Do
    //

}

