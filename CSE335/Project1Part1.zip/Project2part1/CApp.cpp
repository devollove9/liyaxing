/*!
 * \file CApp.cpp
 *
 * \author Charles B. Owen
 */

#include "wx/prec.h"
#include "CApp.h"
#include "CFrame.h"


/*! \brief Constructor
 */
CApp::CApp()
{
    mFrame = NULL;
}

/*! \brief Destructor
 */
CApp::~CApp()
{
    // TODO Auto-generated destructor stub
}


/*! \brief Called when application starts
 * 
 * This function is called once when the
 * application is started. It creates the main frame for
 * the program and displays it.
 * \returns true if successfully initialized
 */
bool CApp::OnInit()
{
    if(!wxApp::OnInit()) {
        return false;
    }
    
    wxLog::SetActiveTarget(new wxLogStream());

    wxInitAllImageHandlers();
    mFrame = new CFrame();
    mFrame->Show(true);
    SetTopWindow(mFrame);
       
    return true;
}
