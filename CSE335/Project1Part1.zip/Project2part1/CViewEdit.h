/*!
* \file CViewEdit.h
*
* This is the main window we will use for editing out documents.
*
* \author Charles B. Owen
*/

#pragma once
#ifndef CVIEWEDIT_H_
#define CVIEWEDIT_H_

#include "CDocumentObserver.h"
#include "CDocument.h"
#include "CDrawable.h"
#include "CActor.h"

class CFrame;

/*! \brief A view class where we can edit the actual graphics
 */
class CViewEdit : public wxScrolledWindow, public CDocumentObserver
{
public:
    CViewEdit(CFrame *parent);
    virtual ~CViewEdit();

    void OnPaint(wxPaintEvent &event);
    void OnLeftButtonDown(wxMouseEvent &event);
    void OnMouseMove(wxMouseEvent &event);
    void OnFocus(wxFocusEvent &event);
    void UpdateObserver();

    // Notice:  Don't put anything between DECLARE_EVENT_TABLE() and private:
    DECLARE_EVENT_TABLE()

private:
    //! The last known mouse location
    wxPoint mLastMouse;
    
    //! Pointer to the frame that uses this view
    CFrame *mFrame;
    
    //! The mouse selected actor
    CActor *mSelectedActor;
    
    //! The mouse selected drawable
    CDrawable *mSelectedDrawable;
};

#endif /* CVIEWEDIT_H_ */
