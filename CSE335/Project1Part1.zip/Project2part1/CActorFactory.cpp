/**
 * \file CActorFactory.cpp
 * 
 * \author Charles B. Owen
 */

#include "wx/prec.h"
#include "CActorFactory.h"

/*! \brief Constructor
 */
CActorFactory::CActorFactory() 
{
    mTextBubble = NULL;
}

/*! \brief Destructor
 */
CActorFactory::~CActorFactory() {
}

