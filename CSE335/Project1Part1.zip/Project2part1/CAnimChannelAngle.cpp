/*!
 * \file CAnimChannelAngle.cpp
 *
 * \author Charles B. Owen
 */

#include "wx/prec.h"
#include "CAnimChannelAngle.h"
#include "CTimeline.h"

/*! \brief Constructor
 */
CAnimChannelAngle::CAnimChannelAngle()
{


}

/*! \brief Destructor
 */
CAnimChannelAngle::~CAnimChannelAngle()
{

}


/*! \brief Get the number of keyframes in the collection
 * \returns Number of keyframes
 */
int CAnimChannelAngle::GetNumKeyframes()
{
    return (int)mKeyframes.size();
}

/*! \brief Get the keyframe given an index
 * \param frame Index to the keyframe
 * \returns The keyframe for that index
 */
CAnimChannel::Keyframe *CAnimChannelAngle::GetKeyframe(int frame)
{
    return &mKeyframes[frame];
}


/*! \brief Set a keyframe a the current time
 * \param angle The angle for the keyframe in radians
 */
void CAnimChannelAngle::SetKeyframe(double angle)
{
    // Create a keyframe object
    KeyframeAngle keyframe;
    keyframe.SetFrame(GetTimeline()->GetCurrentFrame());
    keyframe.SetAngle(angle);

    switch(GetInsertAction())
    {
    case Append:
        mKeyframes.push_back(keyframe);
        mKeyframe1 = (int)mKeyframes.size() - 1;
        break;

    case Replace:
        mKeyframes[mKeyframe1] = keyframe;
        break;

    case Insert:
        mKeyframes.insert(mKeyframes.begin() + mKeyframe1 + 1, keyframe);
        mKeyframe1++;
        break;
    }
}

/*! \brief Get the current angle for this time
 * \returns Angle in radians
 */
double CAnimChannelAngle::GetAngle()
{
    // If no keyframes we just return zero
    if(mKeyframe1 < 0 && mKeyframe2 < 0)
        return 0;

    // If we only have one keyframe, return its value
    if(mKeyframe2 < 0)
        return mKeyframes[mKeyframe1].GetAngle();

    // Same if either is the only keyframe
    if(mKeyframe1 < 0)
        return mKeyframes[mKeyframe2].GetAngle();

    //
    // We have two keyframes. Interpolate between them.
    //

    const double PI = 3.14159265358;
    double angleFm = mKeyframes[mKeyframe1].GetAngle();
    double angleTo = mKeyframes[mKeyframe2].GetAngle();

    // Ensure we always go the short way around
    if(angleTo > angleFm)
    {
        while((angleTo - angleFm) > PI)
            angleTo -= 2 * PI;
    }
    else
    {
        while((angleTo - angleFm) < -PI)
            angleTo += 2 * PI;
    }

    // What is our t value?
    double frameRate = GetTimeline()->GetFrameRate();
    double t = (GetTimeline()->GetCurrentTime() * frameRate - mKeyframes[mKeyframe1].GetFrame()) /
                (mKeyframes[mKeyframe2].GetFrame() - mKeyframes[mKeyframe1].GetFrame());

    return angleFm + t * (angleTo - angleFm);
}


/*! \brief Delete a keyframe at k.
 * \param k The keyframe to delete
 */
void CAnimChannelAngle::DeleteKeyframe(int k)
{
    mKeyframes.erase(mKeyframes.begin() + k);
}


/*! \brief Create an XML node that saves the animation channel
 * \returns The created XML node
 */
wxXmlNode *CAnimChannelAngle::XmlSave()
{
    wxXmlNode *root = CAnimChannel::XmlSave();

    root->AddAttribute(L"type", L"angle");

    wxXmlNode *lastChild = NULL;
    for(std::vector<KeyframeAngle>::iterator f=mKeyframes.begin(); f!=mKeyframes.end();  f++)
    {
        // f in this case is a pointer to an actual keyframe and
        // does not need the two levels of indirection in this case.
        wxXmlNode *node = f->XmlSave();

        // If we have a previous child, add this node after
        // the child.
        if(lastChild == NULL)
        {
            root->AddChild(node);
        }
        else
        {
            lastChild->SetNext(node);
        }

        lastChild = node;
    }

    return root;
}

/*! \brief Save a keyframe to an xml node.
 * \returns The new keyframe node
 */
wxXmlNode *CAnimChannelAngle::KeyframeAngle::XmlSave()
{
    // Create a new node for the keyframe
    wxXmlNode *node = CAnimChannel::Keyframe::XmlSave();

    node->AddAttribute(L"angle", wxString::Format(L"%f", mAngle));

    return node;
}


/*! \brief Clear the angle channel keyframes.
 */
void CAnimChannelAngle::Clear()
{
    CAnimChannel::Clear();
    mKeyframes.clear();
}


/*! \brief Load animation channel data from a file.
 * \param node The node to load from
 */
void CAnimChannelAngle::XmlLoad(wxXmlNode *node)
{
    // The form of the file is:
    //      <channel name="background:Background" type="angle">
    //        <keyframe frame="0" angle="0.000000"/>
    //        <keyframe frame="30" angle="0.000000"/>
    //      </channel>
    //      <channel name="Harold:position" type="point">
    //        <keyframe frame="0" x="400" y="500"/>
    //        <keyframe frame="30" x="533" y="425"/>
    //      </channel>
    // We are looping over the children of the channel tag

    wxXmlNode *child = node->GetChildren();
    while(child != NULL)
    {
        if(child->GetName() == L"keyframe")
        {
            // We have a keyframe node
            // Create a keyframe object
            KeyframeAngle keyframe;

            // Load it
            keyframe.XmlLoad(child);

            // And add to the list
            mKeyframes.push_back(keyframe);
        }

        child = child->GetNext();

    }

    // Do any base class finish-up
    CAnimChannel::XmlLoad(node);
}


/*! \brief Load the XML node for a keyframe.
 * \param  node the XML node containing the keyframe data
 */
void CAnimChannelAngle::KeyframeAngle::XmlLoad(wxXmlNode *node)
{
    // Call the base class version
    CAnimChannel::Keyframe::XmlLoad(node);
    mAngle = wcstod(node->GetAttribute(L"angle", L"0"), NULL);
}
