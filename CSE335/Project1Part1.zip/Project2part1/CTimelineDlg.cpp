/*!
 * \file CTimelineDlg.cpp
 *
 * \author Charles B. Owen
 */

#include "wx/prec.h"
#include <sstream>
#include "CTimelineDlg.h"
#include "CTimeline.h"

using namespace std;

BEGIN_EVENT_TABLE(CTimelineDlg, wxDialog)
    EVT_BUTTON(ID_Ok, CTimelineDlg::OnOkButton)
    EVT_BUTTON(ID_Cancel, CTimelineDlg::OnCancelButton)
END_EVENT_TABLE()

/*! \brief Constructor for a timeline dialog box. 
 * 
 * Initializes the parent dialog box class and constructs 
 * the controls for the dialog box.
 * \param parent A parent window for the dialog box.
 * \param timeline The timeline class we are editing   
 */
CTimelineDlg::CTimelineDlg(wxWindow *parent, CTimeline *timeline) :
    wxDialog(parent, wxID_ANY, L"Timeline Parameters", 
             wxDefaultPosition, wxDefaultSize, wxDEFAULT_DIALOG_STYLE),
    mTimeline(timeline)
{
    // Create a vertical sizer so we have a top part of the box
    // for the options and a bottom part for the Ok and Cancel buttons
    wxBoxSizer* vSizer;
    vSizer = new wxBoxSizer( wxVERTICAL );
    
    // Create the grid sizer for the controls that edit the parameters
    wxGridSizer *gSizer = new wxGridSizer(2);
    vSizer->Add(gSizer, 0, wxALL | wxEXPAND, 20);
    
    //
    // Number of frames
    //
    
    wxStaticText *label1 = new wxStaticText( this, wxID_ANY, L"Number of Frames:", wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT );
    gSizer->Add( label1, 0, wxALIGN_RIGHT | wxALIGN_CENTER_VERTICAL | wxALL);
    
    // Convert number of frames to a string
    wstringstream str1;
    str1 << timeline->GetNumFrames();

    // Create the text control
    mNumFramesText = new wxTextCtrl( this, ID_NumFrames, str1.str().c_str(), wxDefaultPosition, wxDefaultSize, 0 );
    gSizer->Add( mNumFramesText, 0, wxALL);

    //
    // Frame Rate
    //
    
    wxStaticText *label2 = new wxStaticText( this, wxID_ANY, L"Frame Rate:", wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT );
    gSizer->Add( label2, 0, wxALIGN_RIGHT | wxALIGN_CENTER_VERTICAL | wxALL);
    
    // Convert number of frames to a string
    wstringstream str2;
    str2 << timeline->GetFrameRate();

    // Create the text control
    mFrameRateText = new wxTextCtrl( this, ID_FrameRate, str2.str().c_str(), wxDefaultPosition, wxDefaultSize, 0 );
    gSizer->Add( mFrameRateText, 0, wxALL);

    // Create a horizontal sizer that will hold the Ok and Cancel buttons
    // and add it to the vertical sizer.
    wxBoxSizer *hSizer;
    hSizer = new wxBoxSizer(wxHORIZONTAL);
    vSizer->Add(hSizer, 0, wxALL | wxEXPAND);

    // Create an Ok button and add it to the horizontal sizer.
    mOkButton = new wxButton( this, ID_Ok, L"Ok", wxDefaultPosition, wxDefaultSize, 0 );
    hSizer->Add(mOkButton, 1, wxALL | wxEXPAND);
    mOkButton->SetDefault();
    
    // Create a Cancel button and add to the horizontal sizer
    mCancelButton = new wxButton( this, ID_Cancel, L"Cancel", wxDefaultPosition, wxDefaultSize, 0 );
    hSizer->Add(mCancelButton, 1, wxALL | wxEXPAND);

    // Set the top level sizer and force the window to match the size
    this->SetSizer( vSizer ); 
    this->Layout();
    vSizer->Fit( this );
    
    mNumFramesText->SetFocus();
}

/*! \brief Destructor
 */
CTimelineDlg::~CTimelineDlg()
{
}


/*! \brief Handle an Ok button press.
 * \param event The command event
 */
void CTimelineDlg::OnOkButton(wxCommandEvent &event)
{
    // Get the value from the control
    // mNumFramesText is of type wxTextCtrl *
    // mNumFramesText->GetValue is of type wxString
    // wxString::ToLong obtains a value as an integer.
    long numFrames;
    if(!mNumFramesText->GetValue().ToLong(&numFrames) || numFrames <= 0)
    {
        // If the value is bad, set the focus to the control and
        // return without saving the value.
        mNumFramesText->SetFocus();
        return;
    }

    // Get the value from the control
    // mNumFramesText is of type wxTextCtrl *
    // mNumFramesText->GetValue is of type wxString
    // wxString::ToLong obtains a value as an integer.
    long frameRate;
    if(!mFrameRateText->GetValue().ToLong(&frameRate) || numFrames <= 0)
    {
        // If the value is bad, set the focus to the control and
        // return without saving the value.
        mFrameRateText->SetFocus();
        return;
    }

    // All values have been obtained. Set them in the timeline object.
    mTimeline->SetNumFrames(numFrames);
    
    // All values have been obtained. Set them in the timeline object.
    mTimeline->SetFrameRate(frameRate);
    
    EndModal(wxOK);
}

/*! \brief Handle an Cancel button press.
 * \param event The command event
 */
void CTimelineDlg::OnCancelButton(wxCommandEvent &event)
{
    EndModal(wxCANCEL);
}
