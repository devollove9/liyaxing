/*!
 * \file CTimelineDlg.h
 * 
 * The timeline properties dialog box.
 * 
 * \author Charles B. Owen
 */

#ifndef CTIMELINEDLG_H
#define CTIMELINEDLG_H

class CTimeline;

/*! \brief The timeline properties dialog box.
 */
class CTimelineDlg : public wxDialog
{
public:
    CTimelineDlg(wxWindow *parent, CTimeline *timeline);
    virtual ~CTimelineDlg();
    
    //! Id values for our controls
    enum Ids {ID_Ok, ID_Cancel, ID_FrameRate, ID_NumFrames};
    
    void OnOkButton(wxCommandEvent &event);
    void OnCancelButton(wxCommandEvent &event);
    
    // Don't put anything between this line and the next 
    // private, protected, or public.
    DECLARE_EVENT_TABLE()

private:
    //! \brief Default constructor (disabled)
    CTimelineDlg();
    //! \brief Copy constructor (disabled)
    CTimelineDlg(const CTimelineDlg &);
    //! \brief Assignment operator (disabled)
    CTimelineDlg &operator=(const CTimelineDlg &);

    //! Pointer to the timeline object we are editing
    CTimeline *mTimeline;
    
    wxTextCtrl *mFrameRateText;         //!< Frame rate text control
    wxTextCtrl *mNumFramesText;         //!< Number of frames text control
    wxButton *mOkButton;                //!< Ok button control
    wxButton *mCancelButton;            //!< Cancel button control
};

#endif    /* CTIMELINEDLG_H */
