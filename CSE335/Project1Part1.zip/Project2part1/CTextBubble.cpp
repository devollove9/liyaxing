/*
 * Name:     CTextBubble.cpp
 * This class implements a basic text bubble control.
 *
 * Class:    CTextBubble
 * Header:   CTextBubble.h
 * Created : Feb 28, 2010
 * Author :  Charles B. Owen
 */

#include "CTextBubble.h"
#include  <sstream>

#include <iostream>

using namespace std;

//! The maximum width in pixels for a line of text
const int MaxWidth = 125;

//! Locations of the text area of the bubble - left
const double Left = 14.0 / 256.0;

//! Right location of the text bubble area
const double Right = 242.0 / 256.0;

//! Top location of the text bubble area
const double Top = 16.0/ 128.0;

//! Bottom location of the text bubble area
const double Bottom = 88.0 / 128.0;

//! Location of the tip of the bubble: x
const double TipX = 106.0 / 256.0;

//! Location of the tip of the bubble: y
const double TipY = 125.0 / 128.0;


/*! Constructor for out text bubble class.  Loads the image file and creates a font to use.
 */
CTextBubble::CTextBubble()
{
    // Load the image we will use
    if(!mImage.LoadFile(L"images/cartoon_bubble.png"))
    {
        wxMessageBox(L"Unable to open file images/cartoon_bubble.png");
    }

    // Set defaults
    mPosition = wxPoint(200, 200);
    mMirror = false;

    // Force it to realize the string is new
    mNewString = true;

    // Create a font to use
    mFont.Create(8, wxFONTFAMILY_SWISS, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL);
}


/*! Destructor...
 */
CTextBubble::~CTextBubble()
{
}



/*! Draw the text bubble.
 * \param dc The device context to draw on
 */
void CTextBubble::DrawMe(wxDC *dc)
{
    // Anytime the string is updated, we have to recompute the lines on the screen
    if(mNewString)
    {
        NewString(dc);
    }

    // An empty text bubble is not drawn at all.
    if(mSplitText.empty())
        return;

    // We save off the foreground color in case someone
    // else expects it to not change.
    wxColour saveColor = dc->GetTextForeground();
    dc->SetTextForeground(*wxWHITE);

    // Determine where the bitmap will appear on the screen.
    int wid = mBitmap.GetWidth();
    int hit = mBitmap.GetHeight();

    int x = int(mPosition.x - (wid * (mMirror ? 1 - TipX : TipX)));
    int y = int(mPosition.y - (hit * TipY));

    dc->DrawBitmap(mBitmap, x, y, true);

    int ty = int(y + Top * hit);
    for(vector<wxString>::iterator i=mSplitText.begin(); i!=mSplitText.end();  i++)
    {
        wxCoord w, h;
        dc->GetTextExtent(*i, &w, &h);

        dc->DrawText(*i, x + wid / 2 - w / 2, ty);

        ty += h;
    }

    dc->SetTextForeground(saveColor);
}


/*! This function determines if a point is inside the text bubble.
 * \param x X location to test
 * \param y Y location to test
 * \returns true if point is inside the text bubble.
 */
bool CTextBubble::IsPointInside(int x, int y)
{
    // An empty text bubble is not drawn at all.
    if(mSplitText.empty())
        return false;

    // Determine where the bitmap will appear on the screen.
    int wid = mImageScaled.GetWidth();
    int hit = mImageScaled.GetHeight();

    x -= int(mPosition.x - (wid * (mMirror ? 1 - TipX : TipX)));
    y -= int(mPosition.y - (hit * TipY));

    if(x < 0 || y < 0 || x >= wid || y >= hit)
        return false;

    return !mImageScaled.HasAlpha() || mImageScaled.GetAlpha(x, y) > 0;
}



/*! Handle when we get a new string.
 *
 * We have to break it into lines of no more than
 * a defined length in pixels and make the text bubble
 * the correct size.
 * \param dc A device context
 */
void CTextBubble::NewString(wxDC *dc)
{
    mNewString = false;
    mSplitText.clear();


    // A stream to read the text from
    wstringstream str(mText);

    // A wxString to write text into
    wxString line;

    int hit = 0;
    int maxwid = 1;

    //
    // Pull one word at a time and add to a line
    // until we are to wide.
    //

    while(!str.eof())
    {
        wstring word;
        str >> word;

        // Is our line empty? If so, just add the word
        if(line.IsEmpty())
        {
            line = word.c_str();
        }
        else
        {
            // The line is not empty. See how long this would
            // make the line in pixels.
            wxString line2 = line + L" " + word.c_str();
            wxCoord w, h;
            dc->GetTextExtent(line2, &w, &h);
            if(w <= MaxWidth)
            {
                line = line2;
            }
            else
            {
                // Add to our height and determine the maximum width
                dc->GetTextExtent(line, &w, &h);
                hit += h;
                if(w > maxwid)
                    maxwid = w;

                mSplitText.push_back(line);
                line = word.c_str();
            }
        }
    }

    if(!line.IsEmpty())
    {
        wxCoord w, h;
        dc->GetTextExtent(line, &w, &h);
        hit += h;
        if(w > maxwid)
            maxwid = w;

        mSplitText.push_back(line);
    }

    if(mSplitText.empty())
    {
        return;
    }

    // What size does the image need to be?
    int imageWid = int( double(maxwid / (Right - Left)) );
    int imageHit = int( double(hit / (Bottom - Top)) );

    mImageScaled = mImage.Scale(imageWid, imageHit);
    if(mMirror)
        mImageScaled = mImageScaled.Mirror();

    mBitmap = mImageScaled;
}

/*! Set the text we draw in the text bubble.
 * \param str The new string to set as the text
 */
void CTextBubble::SetText(const std::wstring &str)
{
    mText = str;
    mNewString = true;
}
