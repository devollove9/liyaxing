/*!
 * \file CRotatedBitmap.cpp
 *
 * \author Charles B. Owen
 */

#include "wx/prec.h"
#include "CRotatedBitmap.h"

/*! \brief Default Constructor
 */
CRotatedBitmap::CRotatedBitmap()
{
    mCenter = wxPoint(0, 0);
    mRotatedBitmapValid = false;
    mLoaded = false;
}

/*! \brief Destructor
 */
CRotatedBitmap::~CRotatedBitmap()
{
}


/*! Load a file into this bitmap.
 * \param filename The filename to load
 */
void CRotatedBitmap::LoadFile(const std::wstring &filename)
{
    mImage.LoadFile(filename.c_str());
    mLoaded = true;
}


/*! \brief Draw the bitmap
 * \param dc The device context
 * \param position Position to place this bitmap
 * \param angle Angle to draw this bitmap
 */
void CRotatedBitmap::DrawBitmap(wxDC *dc, wxPoint position, double angle)
{
    // See if the bitmap we have is invalid...
    if(!mRotatedBitmapValid || mBitmapR != angle)
    {
        // Create a new rotated image
        wxPoint offsetAfterRotation;
        mRotatedImage = mImage.Rotate(angle, mCenter, true, &offsetAfterRotation);

        // Compute the location of the center point after rotation
        mBitmapCenter = mCenter - offsetAfterRotation;

        // And create a bitmap from the rotated image.
        mRotatedBitmap = wxBitmap(mRotatedImage);
        mBitmapR = angle;
        mRotatedBitmapValid = true;
    }

    // Draw it relative to the new center of the bitmap
    dc->DrawBitmap(mRotatedBitmap, position.x - mBitmapCenter.x, position.y - mBitmapCenter.y, true);
}
