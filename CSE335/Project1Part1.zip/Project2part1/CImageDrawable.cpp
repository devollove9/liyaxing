/* 
 * File:   CImageDrawable.cpp
 * Author: cbowen
 * 
 * Created on October 13, 2013, 3:00 PM
 */

#include "wx/prec.h"
#include "CImageDrawable.h"

/*! Constructor for an image-based drawable.
 * \param name Name of the drawable
 * \param filename Filename for the drawable image
 */
CImageDrawable::CImageDrawable(const std::wstring &name, const std::wstring &filename) : CDrawable(name)
{
    LoadFile(filename);         // Load the file into CRotatedBitmap
}

CImageDrawable::~CImageDrawable()
{
}


/*! \brief Draw the drawable image.
 * \param dc Device context
 */
void CImageDrawable::Draw(wxDC *dc)
{
    DrawBitmap(dc, mPlacedPosition, mPlacedR);
}



/*! \brief Test to see if we hit this object with a mouse.
 * \param pos x,y postion
 * \return true if hit.
 */
bool CImageDrawable::HitTest(wxPoint pos)
{
    // Make x and y relative to the top-left corner of the rotated image
    pos -= mPlacedPosition - mBitmapCenter;
    int x = pos.x;
    int y = pos.y;

    if(x < 0 || y < 0 || x >= mRotatedImage.GetWidth() || y >= mRotatedImage.GetHeight())
    {
        // We are outside the image
        return false;
    }

    return !mRotatedImage.HasAlpha() || mRotatedImage.GetAlpha(x, y) > 0;
}

