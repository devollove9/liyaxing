/*!
* \file CViewTimeline.h
*
* A view window that will display our timeline for animation editing.
*
* \author Charles B. Owen
*/

#pragma once
#ifndef CVIEWTIMELINE_H_
#define CVIEWTIMELINE_H_

#include "CDocumentObserver.h"

class CFrame;

/*! \brief A view class we will use to display a timeline
 */
class CViewTimeline : public wxScrolledWindow, public CDocumentObserver
{
public:
    CViewTimeline(CFrame *parent);
    virtual ~CViewTimeline();

    void UpdateObserver();
        
    //! \brief Handle a resize event
    void OnSize(wxSizeEvent &event) {Refresh();}
    void OnPaint(wxPaintEvent &event);
    void OnKeyDown(wxKeyEvent &event);
    void OnFocus(wxFocusEvent &event);
    void OnLeftButtonDown(wxMouseEvent &event);
    void OnMouseMove(wxMouseEvent &event);
    
    // Notice:  Don't put anything between DECLARE_EVENT_TABLE() and private:
    DECLARE_EVENT_TABLE()

private:
    //! Pointer to the frame that uses this view
    CFrame *mFrame;
    
    //! Bitmap image for the pointer
    wxBitmap  mPointer;
    
    bool mMovingPointer;        //!< True if the pointer is dragging
};

#endif /* CVIEWTIMELINE_H_ */
