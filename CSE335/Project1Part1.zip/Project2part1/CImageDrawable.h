/*!
 * \file CImageDrawable.h
 * 
 * Class for a drawable consisting of an image
 * 
 * \author Charles B. Owen
 */
#ifndef CIMAGEDRAWABLE_H
#define	CIMAGEDRAWABLE_H

#include "CDrawable.h"
#include "CRotatedBitmap.h"

/*! \brief Class for a drawable consisting of an image
 */
class CImageDrawable : public CDrawable, public CRotatedBitmap
{
public:
    CImageDrawable(const std::wstring &name, const std::wstring &filename);
    virtual ~CImageDrawable();
    
    void Draw(wxDC *dc);
    bool HitTest(wxPoint pos);
    
    void SetCenter(wxPoint center) {mCenter = center;}
    wxPoint GetCenter() {return mCenter;}
    
private:
    //! \brief Default constructor (disabled)
    CImageDrawable();

    //! \brief Copy constructor (disabled)
    CImageDrawable(const CImageDrawable &);

    //! \brief Assignment operator (disabled)
    CImageDrawable &operator=(const CImageDrawable &);
};

#endif	/* CIMAGEDRAWABLE_H */

