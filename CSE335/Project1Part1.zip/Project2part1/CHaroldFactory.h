/* 
 * \file CHaroldFactory.h
 * 
 * This is the factory class that makes the Harold character
 * 
 * \author Charles B. Owen
 */

#ifndef CHAROLDFACTORY_H
#define	CHAROLDFACTORY_H

#include "CActorFactory.h"

/*! \brief A factory to make the Harold character
 */
class CHaroldFactory : public CActorFactory
{
public:
    CHaroldFactory();
    virtual ~CHaroldFactory();
    
    CActor *Create();
    
private:
    //! \brief Copy constructor (disabled)
    CHaroldFactory(const CHaroldFactory &);

    //! \brief Assignment operator (disabled)
    CHaroldFactory &operator=(const CHaroldFactory &);
    

};

#endif	/* CHAROLDFACTORY_H */

