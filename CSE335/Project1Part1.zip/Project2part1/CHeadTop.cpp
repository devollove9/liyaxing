/*!
 * \file CHeadTop.cpp
 *
 * \author Charles B. Owen
 */

#include "wx/prec.h"
#include "CHeadTop.h"
#include "CTimeline.h"
#include "CActor.h"

/*! \brief Constructor for a top of the head object
 * \param name The drawable name to use
 * \param filename The filename for the image to use
 */
CHeadTop::CHeadTop(const std::wstring &name, const std::wstring &filename) :
    CImageDrawable(name, filename)
{
    mEyesCenter = wxPoint(55, 79);
    mInterocularDistance = 27;
}

/*! \brief Destructor
 */
CHeadTop::~CHeadTop()
{
}

/*! \brief Set the timeline for the head top channel
 * \param timeline The timeline class.
 */
void CHeadTop::SetTimeline(CTimeline *timeline)
{
    CImageDrawable::SetTimeline(timeline);
    timeline->AddChannel(&mPositionChannel);
}


/*! \brief Set a keyframe on an actor head top
 */
void CHeadTop::SetKeyframe()
{
    CImageDrawable::SetKeyframe();
    mPositionChannel.SetKeyframe(GetPosition());
}

/*! \brief Get a keyframe for an actor head top
 */
void CHeadTop::GetKeyframe()
{
    CImageDrawable::GetKeyframe();
    if(mPositionChannel.GetNumKeyframes() > 0)
        SetPosition(mPositionChannel.GetPoint());
}



/*! \brief Draw the head. 
 * 
 * Up-calls the original version, then adds
 * the eyes and eyebrows.
 * \param dc The Device context
 */
void CHeadTop::Draw(wxDC *dc)
{
    CImageDrawable::Draw(dc);

    // Distance horizontally from each eye center to the center
    int d2 = mInterocularDistance / 2;

    // Compute a left and right eye center X location
    int rightX = mEyesCenter.x - d2;
    int leftX = mEyesCenter.x + d2;

    // Eye center Y value
    int eyeY = mEyesCenter.y;

    if(mLeftEye.IsLoaded() && mRightEye.IsLoaded())
    {
        // Determine the point on the screen were we will draw the left eye
        wxPoint leye = TransformPoint(wxPoint(leftX, eyeY));
        // And draw the bitmap there
        mLeftEye.DrawBitmap(dc, leye, mPlacedR);
        // Repeat the process for the right eye.
        wxPoint reye = TransformPoint(wxPoint(rightX, eyeY));
        mRightEye.DrawBitmap(dc, reye, mPlacedR);
    }
    else
    {
        // Conventional oval and line solution
        wxPen epen(wxColour(0, 0, 0), 2);
        dc->SetPen(epen);

        DrawTransformedLine(dc, rightX - 10, eyeY - 16, rightX + 4, eyeY - 18);
        DrawTransformedLine(dc, leftX - 4, eyeY - 20, leftX + 9, eyeY - 18);

        wxPen epen2(wxColour(0, 0, 0), 0);
        dc->SetBrush(*wxBLACK_BRUSH);
        dc->SetPen(epen2);

        DrawTransformedEllipse(dc, rightX, eyeY, 14, 20);
        DrawTransformedEllipse(dc, leftX, eyeY, 14, 20);

        dc->SetPen(wxNullPen);
        dc->SetBrush(wxNullBrush);
    }
}

/*! \brief Transform a point from a location on the bitmap to
 * a location on the screen.
 * \param p Point to transform
 * \returns Transformed point
 */
wxPoint CHeadTop::TransformPoint(wxPoint p)
{
    // Make p relative to the image center
    p -= GetCenter();

    // Rotate as needed and offset
    return RotatePoint(p, mPlacedR) + mPlacedPosition;
}


/*! \brief Set the actor that uses this drawable.
 * \param actor The actor that uses us.
 */
void CHeadTop::SetActor(CActor *actor)
{
    CImageDrawable::SetActor(actor);

    // Set the channel name
    mPositionChannel.SetName(actor->GetName() + L":" + GetName() + L":position");
}


/*! \brief Draw a line, automatically transforming the points
 * 
 * Draw a line from (x1, y1) to (x2, y2) after transformation
 * to the local coordinate system.
 * \param dc The device context
 * \param x1 Point 1 x
 * \param y1 Point 1 y
 * \param x2 Point 2 x
 * \param y2 Point 2 y
 */
void CHeadTop::DrawTransformedLine(wxDC *dc, int x1, int y1, int x2, int y2)
{
    wxPoint eb1 = TransformPoint(wxPoint(x1, y1));
    wxPoint eb2 = TransformPoint(wxPoint(x2, y2));

    dc->DrawLine(eb1, eb2);
}

/*! \brief Draw an ellipse centered on the point x, y with the supplied width and height.
 * \param dc The device context
 * \param x Center of the ellipse X
 * \param y Center of the ellipse Y
 * \param w Width of the ellipse
 * \param h Height of the ellipse
 */
void CHeadTop::DrawTransformedEllipse(wxDC *dc, int x, int y, int w, int h)
{
    wxPoint loc = TransformPoint(wxPoint(x, y));

    dc->DrawEllipse(loc.x - w/2, loc.y - h/2, w, h);
}

