/*!
* \file CApp.h
*
* The implementation of the main class for the application. Exactly one object
* of this type will be instantiated when the program starts.
*
* \author Charles B. Owen
*/

#pragma once
#ifndef CAPP_H_
#define CAPP_H_

class CFrame;

/*! \brief The main class for the application. 
 * 
 * Exactly one object of this type will be 
 * instantiated when the program starts.
 */
class CApp : public wxApp
{
public:
    CApp();
    virtual ~CApp();

    virtual bool OnInit();
    
    //! \brief Get a pointer to the program main frame
    CFrame *GetFrame() {return mFrame;}
    
private:
    //! Pointer to program main frame
    CFrame *mFrame;
};

#endif /* CAPP_H_ */
