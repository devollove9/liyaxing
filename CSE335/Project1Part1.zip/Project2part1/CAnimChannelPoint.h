/*!
 * \file CAnimChannelPoint.h
 *
 * An animation channel specific to points (movement)
 *
 * \author Charles B. Owen
 */

#pragma once
#ifndef CANIMCHANNELPOINT_H_
#define CANIMCHANNELPOINT_H_

#include <vector>
#include "CAnimChannel.h"

/*! \brief An animation channel specific to points (movement)
 */
class CAnimChannelPoint: public CAnimChannel
{
public:
    CAnimChannelPoint();
    virtual ~CAnimChannelPoint();

    /*! \brief Nested class that describes a single keyframe for point channels
     */
    class KeyframePoint : public Keyframe
    {
    public:
        /*! \brief Get the point for this keyframe
         * \returns Keyframe point
         */
        wxPoint GetPoint() const {return mPoint;}

        /*! \brief Get the point for this keyframe
         * \param p New keyframe point
         */
        void SetPoint(wxPoint p) {mPoint = p;}
        
        wxXmlNode *XmlSave();
        void XmlLoad(wxXmlNode *node);

    private:
        //! The position for this keyframe
        wxPoint mPoint;
    };

    int GetNumKeyframes();
    Keyframe *GetKeyframe(int frame);
    void SetKeyframe(wxPoint point);
    wxPoint GetPoint();
    void DeleteKeyframe(int k);
    wxXmlNode *XmlSave();
    void Clear();
    void XmlLoad(wxXmlNode *node);
    
private:
    //! List of point keyframes for the channel
    std::vector<KeyframePoint> mKeyframes;};

#endif /* CANIMCHANNELPOINT_H_ */
