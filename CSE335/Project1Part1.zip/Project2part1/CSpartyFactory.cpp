/*!
 * \file CSpartyFactory.cpp
 *
 * \author Charles B. Owen
 */

#include "wx/prec.h"
#include "CSpartyFactory.h"
#include "CActor.h"
#include "CPolyDrawable.h"
#include "CImageDrawable.h"
#include "CHeadTop.h"
#include "CTextBubbleDrawable.h"

/*! \brief Default Constructor
 */
CSpartyFactory::CSpartyFactory()
{
}

/*! \brief Destructor
 */
CSpartyFactory::~CSpartyFactory()
{
}


/*! \brief Create a Sparty character.
 * \returns Pointer to new actor
 */
CActor * CSpartyFactory::Create()
{
    CActor *actor = new CActor(L"Sparty");

    CImageDrawable *torso = new CImageDrawable(L"Torso", L"images/sparty_torso.png");
    torso->SetCenter(wxPoint(69, 144));
    torso->SetPosition(wxPoint(0, -200));
    actor->SetRoot(torso);


    CImageDrawable *lleg = new CImageDrawable(L"Left Leg", L"images/sparty_lleg.png");
    lleg->SetCenter(wxPoint(40, 27));
    lleg->SetPosition(wxPoint(102 - 69, 180 - 144));
    torso->AddChild(lleg);

    CImageDrawable *rleg = new CImageDrawable(L"Right Leg", L"images/sparty_rleg.png");
    rleg->SetCenter(wxPoint(34, 27));
    rleg->SetPosition(wxPoint(36 - 69, 180 - 144));
    torso->AddChild(rleg);
    
    CImageDrawable *larm = new CImageDrawable(L"Left Arm", L"images/sparty_larm.png");
    larm->SetCenter(wxPoint(25, 26));
    larm->SetPosition(wxPoint(120 - 69, 22 - 144));
    torso->AddChild(larm);

    CImageDrawable *rarm = new CImageDrawable(L"Right Arm", L"images/sparty_rarm.png");
    rarm->SetCenter(wxPoint(89, 26));
    rarm->SetPosition(wxPoint(20 - 69, 22 - 144));
    torso->AddChild(rarm);
    
    CImageDrawable *headb = new CImageDrawable(L"Head Bottom", L"images/sparty_lhead.png");
    headb->SetCenter(wxPoint(53, 30));
    headb->SetPosition(wxPoint(0, 37 - 144));
    torso->AddChild(headb);
    
    mTextBubble = new CTextBubbleDrawable(L"TextBubble");
    mTextBubble->SetPosition(wxPoint(20, -130));
    headb->AddChild(mTextBubble);

    CHeadTop *headt = new CHeadTop(L"Head Top", L"images/sparty_head.png");
    headt->SetCenter(wxPoint(52, 143));
    headt->SetPosition(wxPoint(0, -27));
    headt->SetEyesCenter(wxPoint(54, 108));
    headt->SetInterocularDistance(30);
    headt->GetLeftEye()->LoadFile(L"images/sparty_leye.png");
    headt->GetLeftEye()->SetCenter(wxPoint(14, 14));
    headt->GetRightEye()->LoadFile(L"images/sparty_reye.png");
    headt->GetRightEye()->SetCenter(wxPoint(17, 16));
    headb->AddChild(headt);
    
    actor->AddDrawable(lleg);
    actor->AddDrawable(rleg);
    actor->AddDrawable(torso);
    actor->AddDrawable(larm);
    actor->AddDrawable(rarm);
    actor->AddDrawable(headb);
    actor->AddDrawable(headt);
    actor->AddDrawable(mTextBubble);
        
    return actor;
}
