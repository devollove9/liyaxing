/* 
 * File:   CHaroldFactory.cpp
 * Author: cbowen
 * 
 * Created on October 13, 2013, 1:10 PM
 */

#include "wx/prec.h"
#include "CHaroldFactory.h"
#include "CActor.h"
#include "CPolyDrawable.h"
#include "CImageDrawable.h"
#include "CHeadTop.h"
#include "CTextBubbleDrawable.h"

CHaroldFactory::CHaroldFactory() {
}


CHaroldFactory::~CHaroldFactory() {
}

/*! \brief This is a concrete factory method that creates our Harold actor.
 * \returns Pointer to an actor object.
 */
CActor *CHaroldFactory::Create()
{
    CActor *actor = new CActor(L"Harold");

    CImageDrawable *shirt = new CImageDrawable(L"Shirt", L"images/harold_shirt.png");
    shirt->SetCenter(wxPoint(44, 138));
    shirt->SetPosition(wxPoint(0, -114));
    actor->SetRoot(shirt);

    CImageDrawable *vest = new CImageDrawable(L"Vest", L"images/harold_vest.png");
    vest->SetCenter(wxPoint(44, 138));
    shirt->AddChild(vest);

    CImageDrawable *lleg = new CImageDrawable(L"Left Leg", L"images/harold_lleg.png");
    lleg->SetCenter(wxPoint(11, 9));
    lleg->SetPosition(wxPoint(27, 0));
    shirt->AddChild(lleg);

    CImageDrawable *rleg = new CImageDrawable(L"Right Leg", L"images/harold_rleg.png");
    rleg->SetCenter(wxPoint(39, 9));
    rleg->SetPosition(wxPoint(-27, 0));
    shirt->AddChild(rleg);

    CImageDrawable *headb = new CImageDrawable(L"Head Bottom", L"images/harold_headb.png");
    headb->SetCenter(wxPoint(44,31));
    headb->SetPosition(wxPoint(0, -130));
    shirt->AddChild(headb);

    CImageDrawable *headt = new CHeadTop(L"Head Top", L"images/harold_headt_blank.png");
    headt->SetCenter(wxPoint(55, 109));
    headt->SetPosition(wxPoint(0, -31));
    headb->AddChild(headt);
    
    mTextBubble = new CTextBubbleDrawable(L"TextBubble");
    mTextBubble->SetPosition(wxPoint(20, -130));
    headb->AddChild(mTextBubble);

    CPolyDrawable *larm = new CPolyDrawable(L"Left Arm");
    larm->SetColor(wxColour(60, 174, 184));
    larm->SetPosition(wxPoint(50, -130));
    larm->AddPoint(wxPoint(-7, -7));
    larm->AddPoint(wxPoint(-7, 96));
    larm->AddPoint(wxPoint(8, 96));
    larm->AddPoint(wxPoint(8, -7));
    shirt->AddChild(larm);


    CPolyDrawable *rarm = new CPolyDrawable(L"Right Arm");
    rarm->SetColor(wxColour(60, 174, 184));
    rarm->SetPosition(wxPoint(-45, -130));
    rarm->AddPoint(wxPoint(-7, -7));
    rarm->AddPoint(wxPoint(-7, 96));
    rarm->AddPoint(wxPoint(8, 96));
    rarm->AddPoint(wxPoint(8, -7));
    shirt->AddChild(rarm);

    CPolyDrawable *lhand = new CPolyDrawable(L"Left Hand");
    lhand->SetColor(wxColour(253, 218, 180));
    lhand->SetPosition(wxPoint(0, 96));
    lhand->AddPoint(wxPoint(-12, -2));
    lhand->AddPoint(wxPoint(-12, 17));
    lhand->AddPoint(wxPoint(11, 17));
    lhand->AddPoint(wxPoint(11, -2));
    larm->AddChild(lhand);

    CPolyDrawable *rhand = new CPolyDrawable(L"Right Hand");
    rhand->SetColor(wxColour(253, 218, 180));
    rhand->SetPosition(wxPoint(0, 96));
    rhand->AddPoint(wxPoint(-12, -2));
    rhand->AddPoint(wxPoint(-12, 17));
    rhand->AddPoint(wxPoint(11, 17));
    rhand->AddPoint(wxPoint(11, -2));
    rarm->AddChild(rhand);


    actor->AddDrawable(larm);
    actor->AddDrawable(rarm);
    actor->AddDrawable(rhand);
    actor->AddDrawable(lhand);
    actor->AddDrawable(rleg);
    actor->AddDrawable(lleg);
    actor->AddDrawable(shirt);
    actor->AddDrawable(vest);
    actor->AddDrawable(headb);
    actor->AddDrawable(headt);
    actor->AddDrawable(mTextBubble);
    
    return actor;
}
