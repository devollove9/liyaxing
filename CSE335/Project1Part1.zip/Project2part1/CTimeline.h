/*!
 * \file CTimeline.h
 * 
 * A class to keep track of the animation frames.
 * 
 * \author Charles B. Owen
 */

#ifndef CTIMELINE_H
#define CTIMELINE_H

#include <vector>


class CAnimChannel;

/*! \brief A class to keep track of the animation frames.
 */
class CTimeline
{
public:
    CTimeline();
    virtual ~CTimeline();
    
    /*! \brief Get the number of frames in the animation
     * \returns Number of frames in the animation
     */
    int GetNumFrames() const {return mNumFrames;}

    /*! \brief Set the number of frames in the animation
     * \param numFrames Number of frames in the animation
     */
    void SetNumFrames(int numFrames) {mNumFrames = numFrames;}

    /*! \brief Get the frame rate
     * \returns Animation frame rate in frames per second
     */
    int GetFrameRate() const {return mFrameRate;}

    /*! \brief Set the frame rate
     * \param frameRate Animation frame rate in frames per second
     */
    void SetFrameRate(int frameRate) {mFrameRate = frameRate;}

    /*! \brief Get the current time
     * \returns Current animation time in seconds
     */
    double GetCurrentTime() const {return mCurrentTime;}

    void SetCurrentTime(double currentTime);
    
    /*! \brief Get the current frame. 
     *
     * This is the frame associated with the current time
     * \returns Current frame
     */
    int GetCurrentFrame() const {return int(mCurrentTime * mFrameRate);}
    
    /*! \brief Get the animation duration
     * \returns Animation duration in seconds
     */
    double GetDuration() const {return double(mNumFrames) / double(mFrameRate);}

    void AddChannel(CAnimChannel *channel);
    void ClearKeyframe();
    void Save(const std::wstring &filename);
    void Load(const std::wstring &filename);
    void Clear();
    
private:
    //! Copy constructor (disabled)
    CTimeline(const CTimeline &);
    //! Assignment operator (disabled)
    CTimeline &operator=(const CTimeline &);

    int mNumFrames;             //!< Number of frames in the animation
    int mFrameRate;             //!< Number of frames per second
    double mCurrentTime;        //!< Current time in seconds
    
    //! List of all animation channels
    std::vector<CAnimChannel *> mChannels;
};

#endif    /* CTIMELINE_H */
