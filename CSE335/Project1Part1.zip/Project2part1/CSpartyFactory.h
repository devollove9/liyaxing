/*!
 * \file CSpartyFactory.h
 * 
 * A factory that creates the Sparty character
 * 
 * \author Charles B. Owen
 * 
 * \brief 
 */

#ifndef CSPARTYFACTORY_H
#define CSPARTYFACTORY_H

#include "CActorFactory.h"

/*! \brief A factory that creates the Sparty character
 */
class CSpartyFactory : public CActorFactory
{
public:
    CSpartyFactory();
    virtual ~CSpartyFactory();

    CActor *Create();
        
private:
    //! Copy constructor (disabled)
    CSpartyFactory(const CSpartyFactory &);
    //! Assignment operator (disabled)
    CSpartyFactory &operator=(const CSpartyFactory &);

};

#endif    /* CSPARTYFACTORY_H */
