/*!
 * \file CViewEdit.cpp
 *
 * \author Charles B. Owen
 */

#include "wx/prec.h"
#include "CViewEdit.h"
#include "CFrame.h"

using namespace std;

BEGIN_EVENT_TABLE(CViewEdit, wxScrolledWindow)
    EVT_PAINT(CViewEdit::OnPaint)
    EVT_LEFT_DOWN(CViewEdit::OnLeftButtonDown)
    EVT_LEFT_UP(CViewEdit::OnMouseMove)
    EVT_MOTION(CViewEdit::OnMouseMove)
    EVT_SET_FOCUS(CViewEdit::OnFocus)
END_EVENT_TABLE()

//! A scaling factor, converts mouse motion to rotation in radians
const double RotationScaling = 0.02;


/*! \brief Constructor for an editor view.
 * \param frame The frame this view is a member of. The frame owns the document.
 */
CViewEdit::CViewEdit(CFrame *frame) :
    wxScrolledWindow(frame, wxID_ANY, wxDefaultPosition, wxSize(805, 605), 
                     wxHSCROLL | wxVSCROLL | wxBORDER_SUNKEN, L"ViewEdit"),
    CDocumentObserver(frame->GetDocument()),
    mFrame(frame)
{
    mLastMouse = wxPoint(0, 0);
    mSelectedActor = NULL;
    mSelectedDrawable = NULL;

    SetBackgroundColour(wxColour(128, 128, 128));
    SetVirtualSize(GetDocument()->GetSize());
    SetClientSize(GetDocument()->GetSize());
    SetScrollRate(1, 1);
}


/*! \brief Destructor.
 */
CViewEdit::~CViewEdit()
{

}


/*! \brief Force an update of this window when the document changes.
 */
void CViewEdit::UpdateObserver()
{
    Refresh();
}

/*! \brief Handle focus coming to this panel
 * \param event The focus change event
 */
void CViewEdit::OnFocus(wxFocusEvent &event) 
{
#ifdef CSPEECH
    // Speech-specifics
    speak.Delay(0.8);
    speak << "ViewEdit" << std::flush;
#endif
    event.Skip();
}


/*! \brief Handle a draw request for this window.
 * \param event The draw event
 */
void CViewEdit::OnPaint(wxPaintEvent &event)
{
    // Create a device context
    wxPaintDC dc(this);
    dc.SetClippingRegion(wxPoint(0, 0), GetDocument()->GetSize());

    //speak << GetClientRect() << std::flush;
    
    // Offset the device context due to any scrolling
    DoPrepareDC(dc);

    GetDocument()->Draw(&dc);

    dc.SetPen(wxNullPen);
    dc.SetBrush(wxNullBrush);
    dc.SetFont(wxNullFont);
}



/*! \brief Handle left mouse button press
 * This function is called when the left mouse button is clicked
 * on the window.
 * \param event The mouse event
 */
void CViewEdit::OnLeftButtonDown(wxMouseEvent &event)
{
    // Get the view point start and add to the mouse position
    // to determine where we clicked in the scrolled area.
    int x, y;
    GetViewStart(&x, &y);
    x += event.m_x;
    y += event.m_y;

    mLastMouse = wxPoint(x, y);

    //
    // Did we hit anything?
    //

    CIteratorPtr<CActor *> iter = GetDocument()->GetActors();
    CActor *hitActor = NULL;
    CDrawable *hitDrawable = NULL;
    for(iter->First();  !iter->IsDone();  iter->Next())
    {
        // Note: We do not exit when we get the first hit, since
        // we are looking at these in drawing order. Instead, we
        // keep the last hit.
        CActor *actor = iter->Current();
        CDrawable *drawable = actor->HitTest(wxPoint(x, y));
        if(drawable != NULL)
        {
            hitActor = actor;
            hitDrawable = drawable;
        }
    }

    // If we hit something determine what we do with it based on the
    // current mode.
    if(hitActor != NULL)
    {
        mSelectedActor = hitActor;
        mSelectedDrawable = hitDrawable;
    }
}




/*! \brief Handle mouse movement
 * This function is called whenever the mouse is
 * moved over the window.
 * \param event The mouse event
 */
void CViewEdit::OnMouseMove(wxMouseEvent &event)
{
    // Convert the mouse location to a canvas location
    int x, y;
    GetViewStart(&x, &y);
    x += event.m_x;
    y += event.m_y;

    // This code computes a "delta", the amount the mouse has moved
    // since the last call to button down or mouse move.
    wxPoint mouse = wxPoint(x, y);
    wxPoint delta = mouse - mLastMouse;
    mLastMouse = mouse;

    if(event.m_leftDown)
    {
        switch(mFrame->GetMode())
        {
        case CFrame::ID_Move:
            if(mSelectedDrawable != NULL)
            {
                if(mSelectedDrawable->IsMovable())
                {
                    mSelectedDrawable->Move(delta);
                }
                else
                {
                    mSelectedActor->SetPosition(mSelectedActor->GetPosition() + delta);
                }
                mFrame->GetDocument()->UpdateObservers();
            }
            break;

        case CFrame::ID_Rotate:
            if(mSelectedDrawable != NULL)
            {
                mSelectedDrawable->SetRotation(mSelectedDrawable->GetRotation() + delta.y * RotationScaling);
                mFrame->GetDocument()->UpdateObservers();
            }
            break;

        default:
            break;
        }

    }
    else
    {
        mSelectedDrawable = NULL;
        mSelectedActor = NULL;   
    }
}

