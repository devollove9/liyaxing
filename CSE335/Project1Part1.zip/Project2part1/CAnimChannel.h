/*!
 * \file CAnimChannel.h
 *
 * Animation Channel base class
 *
 * \author Charles B. Owen
 */

#pragma once
#ifndef CANIMCHANNEL_H_
#define CANIMCHANNEL_H_

#include <string>

class CTimeline;

/*! \brief Animation Channel base class
 */
class CAnimChannel
{
public:
    CAnimChannel();
    virtual ~CAnimChannel();

    /*! \brief Keyframe nested class
     */
    class Keyframe
    {
    public:
        /*! \brief Get the frame
         * \returns Frame for this keyframe
         */
        int GetFrame() const {return mFrame;}

        /*! \brief Set the frame
         * \param f Frame for this keyframe
         */
        void SetFrame(int f) {mFrame = f;}
        
        virtual wxXmlNode *XmlSave();
        virtual void XmlLoad(wxXmlNode *node);

    private:
        //! The keyframe number
        int mFrame;
    };

    /*! \brief Get the number of keyframes in the collection
     * \returns Number of keyframes
     */
    virtual int GetNumKeyframes() = 0;

    /*! \brief Get the keyframe given an index
     * \param frame Index to the keyframe
     * \returns The keyframe for that index
     */
    virtual Keyframe *GetKeyframe(int frame) = 0;

    /*! \brief Set the name of the channel
     * \param name New channel name
     */
    void SetName(const std::wstring &name) {mName = name;}

    /*! \brief Get the name of the channel
     * \returns Channel name
     */
    std::wstring GetName() const {return mName;}
    
    //! \brief Get the timeline 
    //! \returns Pointer to timeline object
    CTimeline *GetTimeline() {return mTimeline;}
    
    //! \brief Set the timeline pointer
    //! \param t New timeline pointer
    void SetTimeline(CTimeline *t) {mTimeline = t;}
    
    //! Possible type of keyframe insertions
    enum InsertActions {Append, Replace, Insert};
    
    /*! \brief Delete a specific keyframe
     * \param k The keyframe to delete
     */
    virtual void DeleteKeyframe(int k) = 0;
    
    InsertActions GetInsertAction();
    void SetKeyframeIndices();
    void ClearKeyframe();
    virtual wxXmlNode *XmlSave();
    virtual void Clear();
    virtual void XmlLoad(wxXmlNode *node);

protected:
    //! \brief Copy constructor (disabled)
    CAnimChannel(const CAnimChannel &);
    //! \brief Assignment operator (disabled)
    void operator=(const CAnimChannel &);
    
    //! First keyframe for current time
    int mKeyframe1;

    //! Second keyframe for current time
    int mKeyframe2;

private:
    //! The channel name
    std::wstring mName;
    
    //! The timeline object
    CTimeline *mTimeline;
};

#endif /* CANIMCHANNEL_H_ */