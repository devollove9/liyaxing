/* 
 * File:   main.cpp
 * Author: cbowen
 *
 * Created on October 5, 2013, 8:36 PM
 */

#include "wx/prec.h"
#include <cstdlib>
#include "CApp.h"

IMPLEMENT_APP_NO_MAIN(CApp)

int main(int argc, char** argv)
{
    return wxEntry(argc, argv); 
}
