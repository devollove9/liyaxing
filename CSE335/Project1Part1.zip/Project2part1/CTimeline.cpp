/*!
 * \file CTimeline.cpp
 *
 * \author Charles B. Owen
 */

#include "wx/prec.h"
#include <string>
#include <sstream>
#include "CTimeline.h"
#include "CAnimChannel.h"

using namespace std;

/*! \brief Default Constructor
 */
CTimeline::CTimeline()
{
    mNumFrames = 300;
    mFrameRate = 30;
    mCurrentTime = 0;
}

/*! \brief Destructor
 */
CTimeline::~CTimeline()
{
}

/*! \brief Add a channel to the timeline
 * \param channel The channel to add
 */
void CTimeline::AddChannel(CAnimChannel *channel) 
{
    mChannels.push_back(channel);
    channel->SetTimeline(this);
}

/*! \brief Sets the current time
 *
 * Ensures all of the channels are
 * valid for that point in time.
 * 
 * \param t The new time to set
 */
void CTimeline::SetCurrentTime(double t)
{
    // Set the time
    mCurrentTime = t;

    for(std::vector<CAnimChannel *>::iterator c=mChannels.begin(); c!=mChannels.end(); c++)
    {
        (*c)->SetKeyframeIndices();
    }
}

/*! \brief Clear any keyframe at the current time.
 */
void CTimeline::ClearKeyframe()
{
    for(std::vector<CAnimChannel *>::iterator c=mChannels.begin();  c!=mChannels.end();  c++)
    {
        (*c)->ClearKeyframe();
    }
}


/*! \brief Save the timeline information into a node.
 * \param filename The filename to save the information in.
 */
void CTimeline::Save(const std::wstring &filename)
{
    // Create an empty XML document
    wxXmlDocument xmlDoc;

    // Create a root node
    wxXmlNode *root = new wxXmlNode(wxXML_ELEMENT_NODE, L"animation");
    xmlDoc.SetRoot(root);

    root->AddAttribute(L"num-frames", wxString::Format(L"%d", mNumFrames));
    root->AddAttribute(L"frame-rate", wxString::Format(L"%d", mFrameRate));

    wxXmlNode *lastChild = NULL;
    for(std::vector<CAnimChannel *>::const_iterator c = mChannels.begin(); c!=mChannels.end();  c++)
    {
        // Create a node for the channel
        wxXmlNode *node = (*c)->XmlSave();

        // If we have a previous child, add this node after
        // the child.
        if(lastChild == NULL)
        {
            root->AddChild(node);
        }
        else
        {
            lastChild->SetNext(node);
        }

        lastChild = node;
    }

    // And save the file to disk
    if(!xmlDoc.Save(filename.c_str()))
    {
        wxMessageBox(L"Unable to save file.");
    }
}


/*! \brief Load an animation from a file.
 *\param filename The file to load the animation from
 */
void CTimeline::Load(const std::wstring &filename)
{
    wxXmlDocument xmlDoc;
    if(!xmlDoc.Load(filename.c_str()))
    {
        wstringstream str;
        str << L"Unable to open file " << filename << ends;
        wxMessageBox(str.str().c_str(),
                         L"Error",
                          wxOK | wxICON_ERROR);
        return;
    }

    // Clear our existing animation
    Clear();

    // The form of the file is:
    //    <?xml version="1.0" encoding="utf-8"?>
    //    <animation  num-frames="300" frame-rate="30">
    //      <channel name="background:position" type="point">
    //        <keyframe frame="0" x="-100" y="0"/>
    //        <keyframe frame="30" x="-100" y="0"/>
    //      </channel>
    //      <channel name="background:Background" type="angle">
    //        <keyframe frame="0" angle="0.000000"/>
    //        <keyframe frame="30" angle="0.000000"/>
    //      </channel>
    //      <channel name="Harold:position" type="point">
    //        <keyframe frame="0" x="400" y="500"/>
    //        <keyframe frame="30" x="533" y="425"/>
    //      </channel>
    //    </animation>
    // We are looping over the children of the animation tag

    // Load the number of frames and the frame rate
    mNumFrames = wcstol(xmlDoc.GetRoot()->GetAttribute(L"num-frames", L"300"), NULL, 10);
    mFrameRate = wcstol(xmlDoc.GetRoot()->GetAttribute(L"frame-rate", L"30"), NULL, 10);

    // Loop over the children of the root node
    wxXmlNode *child = xmlDoc.GetRoot()->GetChildren();
    while(child != NULL)
    {
        wxString name = child->GetName();
        if(name == L"channel")
        {
            // Get the channel name
            wstring name = child->GetAttribute(L"name", L"").wc_str();

            // Find a channel with that name
            for(std::vector<CAnimChannel *>::iterator c=mChannels.begin();  c!=mChannels.end();  c++)
            {
                CAnimChannel *channel = *c;

                if(channel->GetName() == name)
                {
                    channel->XmlLoad(child);
                    break;
                }
            }

        }

        // Move to the next child
        child = child->GetNext();
    }

}


/*! \brief Clear the timeline.
 */
void CTimeline::Clear()
{
    // Reset the current time and restore to defaults.
    mCurrentTime = 0;
    mNumFrames = 300;
    mFrameRate = 30;
    
    // Clear each channel
    for(std::vector<CAnimChannel *>::iterator c=mChannels.begin();  c!=mChannels.end();  c++)
    {
        (*c)->Clear();
    }
}
