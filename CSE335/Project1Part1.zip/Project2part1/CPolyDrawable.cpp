/* 
 * File:   CPolyDrawable.cpp
 * Author: cbowen
 * 
 * Created on October 12, 2013, 9:07 PM
 */

#include "wx/prec.h"
#include "CPolyDrawable.h"

using namespace std;


/*! \brief Constructor for a polygon object.
 * \param name The name of the object we are creating.
 */
CPolyDrawable::CPolyDrawable(const std::wstring &name) : CDrawable(name)
{
    mColor = *wxBLACK;
}

//! \brief Destructor
CPolyDrawable::~CPolyDrawable()
{
}

/*! \brief Draw our polygon.
 * \param  dc The device context
 */
void CPolyDrawable::Draw(wxDC *dc)
{
    wxBrush brush(mColor);
    dc->SetBrush(brush);

    wxPen pen(mColor, 0);
    dc->SetPen(pen);

    // Transform the points
    vector<wxPoint> points;
    for(vector<wxPoint>::iterator p=mPoints.begin(); p!=mPoints.end(); p++)
    {
        points.push_back(RotatePoint(*p, mPlacedR) + mPlacedPosition);
    }

    dc->DrawPolygon((int)points.size(), &points[0]);

    dc->SetBrush(wxNullBrush);
    dc->SetPen(wxNullPen);

    //speak.Delay(3);
    //speak << "Polygon points";
    
//    for(int i=0; i<points.size();  i++) 
//    {
//        speak << points[i] << flush;
//    }
}

/*! \brief Test to see if we hit this object with a mouse click
 * \param pos Click position
 * \returns true it hit
 */
bool CPolyDrawable::HitTest(wxPoint pos)
{
    // Transform the points
    vector<wxPoint> points;
    for(vector<wxPoint>::iterator p=mPoints.begin(); p!=mPoints.end(); p++)
    {
        points.push_back(RotatePoint(*p, mPlacedR) + mPlacedPosition);
    }

    wxRegion region((int)points.size(), &points[0], wxODDEVEN_RULE);
    return region.Contains(pos) == wxInRegion;
}

/*! \brief Add a point to this polygon
 * \param point Point to add.
 */
void CPolyDrawable::AddPoint(wxPoint point)
{
    mPoints.push_back(point);
}
    

/*! \brief Set the polygon color
 * \param mColor New value for the polygon color
 */
void CPolyDrawable::SetColor(wxColour mColor) {
    this->mColor = mColor;
}

/*! \brief Get the polygon color
 * \returns the polygon color
 */
wxColour CPolyDrawable::GetColor() const {
    return mColor;
}

