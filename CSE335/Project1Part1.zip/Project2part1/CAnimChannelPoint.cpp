/*!
 * \file CAnimChannelPoint.cpp
 *
 * \author Enter_your_name_here
 */

#include "wx/prec.h"
#include "CAnimChannelPoint.h"
#include "CTimeline.h"

/**
 * \brief Default constructor
 */
CAnimChannelPoint::CAnimChannelPoint()
{
}

/**
 * \brief Destructor
 */
CAnimChannelPoint::~CAnimChannelPoint()
{
}



/*! \brief Obtain the number of keyframes.
 *
 * This is the size of the keyframe list.
 * \returns Number of keyframes.
 */
int CAnimChannelPoint::GetNumKeyframes()
{
    return (int)mKeyframes.size();
}


/*! \brief Get a keyframe by index from the list of keyframes.
 * \param frame The frame index
 * \returns Pointer to keyframe at that index.
 */
CAnimChannel::Keyframe *CAnimChannelPoint::GetKeyframe(int frame)
{
    return &mKeyframes[frame];
}


/*! \brief Delete a keyframe at k.
 * \param k The keyframe to delete
 */
void CAnimChannelPoint::DeleteKeyframe(int k)
{
    mKeyframes.erase(mKeyframes.begin() + k);
}


/*! \brief Set a keyframe at the current time.
 * \param point The point for the new keyframe.
 */
void CAnimChannelPoint::SetKeyframe(wxPoint point)
{
    // Create a keyframe object
    KeyframePoint keyframe;
    keyframe.SetFrame(GetTimeline()->GetCurrentFrame());
    keyframe.SetPoint(point);

    switch(GetInsertAction())
    {
    case Append:
        mKeyframes.push_back(keyframe);
        mKeyframe1 = (int)mKeyframes.size() - 1;
        break;

    case Replace:
        mKeyframes[mKeyframe1] = keyframe;
        break;

    case Insert:
        mKeyframes.insert(mKeyframes.begin() + mKeyframe1 + 1, keyframe);
        mKeyframe1++;
        break;
    }

}


/*! \brief Get the current point.
 * \returns The point at this point in time.
 */
wxPoint CAnimChannelPoint::GetPoint()
{
    // If no keyframes we just return zero
    if(mKeyframe1 < 0 && mKeyframe2 < 0)
        return wxPoint(0, 0);

    // If we only have one keyframe, return its value
    if(mKeyframe2 < 0)
        return mKeyframes[mKeyframe1].GetPoint();

    // Same if either is the only keyframe
    if(mKeyframe1 < 0)
        return mKeyframes[mKeyframe2].GetPoint();

    //
    // We have two keyframes. Interpolate between them.
    //

    wxPoint pointFm = mKeyframes[mKeyframe1].GetPoint();
    wxPoint pointTo = mKeyframes[mKeyframe2].GetPoint();


    // What is our t value?
    double frameRate = GetTimeline()->GetFrameRate();
    double t = (GetTimeline()->GetCurrentTime() * frameRate - mKeyframes[mKeyframe1].GetFrame()) /
                (mKeyframes[mKeyframe2].GetFrame() - mKeyframes[mKeyframe1].GetFrame());

    return wxPoint(int(pointFm.x + t * (pointTo.x - pointFm.x)), int(pointFm.y + t * (pointTo.y - pointFm.y)));
}


/*! \brief Create an XML node that saves the animation channel
 * \returns The created XML node
 */
wxXmlNode *CAnimChannelPoint::XmlSave()
{
    wxXmlNode *root = CAnimChannel::XmlSave();

    root->AddAttribute(L"type", L"point");

    wxXmlNode *lastChild = NULL;
    for(std::vector<KeyframePoint>::iterator f=mKeyframes.begin(); f!=mKeyframes.end();  f++)
    {
        // f in this case is a pointer to an actual keyframe and
        // does not need the two levels of indirection in this case.
        wxXmlNode *node = f->XmlSave();

        // If we have a previous child, add this node after
        // the child.
        if(lastChild == NULL)
        {
            root->AddChild(node);
        }
        else
        {
            lastChild->SetNext(node);
        }

        lastChild = node;
    }

    return root;
}



/*! \brief Save a keyframe to an xml node.
 * \returns The new keyframe node
 */
wxXmlNode *CAnimChannelPoint::KeyframePoint::XmlSave()
{
    // Create a new node for the keyframe
    wxXmlNode *node = CAnimChannel::Keyframe::XmlSave();

    node->AddAttribute(L"x", wxString::Format(L"%d", mPoint.x));
    node->AddAttribute(L"y", wxString::Format(L"%d", mPoint.y));

    return node;
}


/*! \brief Clear the point channel keyframes.
 */
void CAnimChannelPoint::Clear()
{
    CAnimChannel::Clear();
    mKeyframes.clear();
}


/*! \brief Load the XML node for a keyframe.
 * \param  node the XML node containing the keyframe data
 */
void CAnimChannelPoint::XmlLoad(wxXmlNode *node)
{
    // The form of the file is:
    //      <channel name="background:Background" type="angle">
    //        <keyframe frame="0" angle="0.000000"/>
    //        <keyframe frame="30" angle="0.000000"/>
    //      </channel>
    //      <channel name="Harold:position" type="point">
    //        <keyframe frame="0" x="400" y="500"/>
    //        <keyframe frame="30" x="533" y="425"/>
    //      </channel>
    // We are looping over the children of the channel tag

    wxXmlNode *child = node->GetChildren();
    while(child != NULL)
    {
        if(child->GetName() == L"keyframe")
        {
            // We have a keyframe node
            // Create a keyframe object
            KeyframePoint keyframe;

            // Load it
            keyframe.XmlLoad(child);

            // And add to the list
            mKeyframes.push_back(keyframe);
        }

        child = child->GetNext();

    }

    // Do any base class finish-up
    CAnimChannel::XmlLoad(node);
}


/*! \brief Load the XML node for a keyframe.
 * \param node The XML node containing the keyframe data
 */
void CAnimChannelPoint::KeyframePoint::XmlLoad(wxXmlNode *node)
{
    // Call the base class version
    CAnimChannel::Keyframe::XmlLoad(node);
    int x = wcstol(node->GetAttribute(L"x", L"0"), NULL, 10);
    int y = wcstol(node->GetAttribute(L"y", L"0"), NULL, 10);

    mPoint = wxPoint(x, y);
}
