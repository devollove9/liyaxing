/* 
 * File:   CDocumentObserver.cpp
 * Author: cbowen
 * 
 * Created on October 10, 2013, 8:48 PM
 */

#include "wx/prec.h"
#include "CDocumentObserver.h"
#include "CDocument.h"

/*! \brief Constructor for a document observer.
 * \param document The document we are observing
 */
CDocumentObserver::CDocumentObserver(CDocument *document) : mDocument(document)
{
    mDocument->AddObserver(this);
}

/*! \brief Destructor for an observer. 
 *
 * Disconnects us from the document we are
 * observing.
 */
CDocumentObserver::~CDocumentObserver()
{
    mDocument->RemoveObserver(this);
}

