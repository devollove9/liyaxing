/**
 * \file CTextBubbleDrawable.cpp
 *
 * \author Charles B. Owen
 */

#include "wx/prec.h"
#include "CTextBubbleDrawable.h"
#include "CTextBubbleDlg.h"
#include "CActor.h"
#include "CTimeline.h"

/*! \brief Constructor
 */
CTextBubbleDrawable::CTextBubbleDrawable(const std::wstring &name) : CDrawable(name)
{

}


/*! \brief Destructor 
 */
CTextBubbleDrawable::~CTextBubbleDrawable()
{
    
}

/*! \brief Draw the text bubble
 * \param dc Device context
 */
void CTextBubbleDrawable::Draw(wxDC *dc)
{
    SetBubblePosition(mPlacedPosition.x, mPlacedPosition.y);
    DrawMe(dc);
}

/*! \brief Test to see if pos hits the drawable
 * \param pos An x,y location in screen coordinates
 * \returns True if hit
 */
bool CTextBubbleDrawable::HitTest(wxPoint pos)
{
    return IsPointInside(pos.x, pos.y);
}


/*! \brief Bring up the text bubble dialog box.
 * \param window A parent window
 */
void CTextBubbleDrawable::DialogBox(wxWindow *window)
{
    CTextBubbleDlg dlg(window, this);
    dlg.ShowModal();
}


/*! \brief Set the actor that uses this drawable.
 * \param actor The actor that uses us.
 */
void CTextBubbleDrawable::SetActor(CActor *actor)
{
    CDrawable::SetActor(actor);

    // Set the channel name
    mPositionChannel.SetName(actor->GetName() + L":" + GetName() + L":textposition");
    mTextChannel.SetName(actor->GetName() + L":" + GetName() + L":text");
}


/*! \brief Set the timeline for all channels.
 * \param timeline The timeline class.
 */
void CTextBubbleDrawable::SetTimeline(CTimeline *timeline)
{
    CDrawable::SetTimeline(timeline);
    timeline->AddChannel(&mPositionChannel);
    timeline->AddChannel(&mTextChannel);
}

/*! \brief Set a keyframe on a text bubble.
 */
void CTextBubbleDrawable::SetKeyframe()
{
    CDrawable::SetKeyframe();
    mPositionChannel.SetKeyframe(GetPosition());
    mTextChannel.SetKeyframe(GetText(), GetMirror());
}

/*! \brief Get a keyframe for the text bubble.
 */
void CTextBubbleDrawable::GetKeyframe()
{
    CDrawable::GetKeyframe();
    if(mPositionChannel.GetNumKeyframes() > 0)
        SetPosition(mPositionChannel.GetPoint());

    if(mTextChannel.GetNumKeyframes() > 0)
    {
        SetText(mTextChannel.GetText());
        SetMirror(mTextChannel.GetMirror());
    }
}
