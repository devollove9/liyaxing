/*!
* \file CFrame.h
*
* This is the main window for the program.
*
* \author Charles B. Owen
*/

#pragma once
#ifndef CFRAME_H_
#define CFRAME_H_

#include "CViewTimeline.h"
#include "CViewEdit.h"
#include "CViewActors.h"

class CDocument;
class CTextBubbleDrawable;

/*! \brief Main application frame class.
 */
class CFrame : public wxFrame
{
public:
    CFrame();
    virtual ~CFrame();

    //! Enum with ids for the menu options
    enum Ids {ID_Exit=1, ID_None, ID_About, ID_ToolBar, ID_Move, ID_Rotate, ID_Keyframe, ID_NoKeyframe,
       ID_AnimationProperties, ID_FileSaveAs, ID_FileOpen, ID_TextBubbleHarold, ID_TextBubbleSparty,
       ID_Play, ID_PlayBeginning, ID_PlayStop, ID_Timer};

    void OnExit(wxCommandEvent& event);
    void OnAbout(wxCommandEvent& event);
    void OnMove(wxCommandEvent& event);
    void OnRotate(wxCommandEvent& event);
    void OnKeyframeSet(wxCommandEvent& event);
    void OnKeyframeClear(wxCommandEvent& event);
    void OnAnimationProperties(wxCommandEvent& event);
    void OnFileOpen(wxCommandEvent &event);
    void OnFileSaveAs(wxCommandEvent &event);
    void OnTextBubbleHarold(wxCommandEvent &event);
    void OnTextBubbleSparty(wxCommandEvent &event);
    void OnPlayPlay(wxCommandEvent &event);
    void OnPlayPlayBeginning(wxCommandEvent &event);
    void OnPlayStop(wxCommandEvent &event);
    void OnTimer(wxTimerEvent &event);
    
    /*! \brief Get the current mouse mode
     * \returns Mouse move as an enum of type Ids
     */
    Ids GetMode() const {return mMode;}
    
    //! \brief Get the document we are viewing
    //! \returns Pointer to document
    CDocument *GetDocument() {return mDocument;}

    DECLARE_EVENT_TABLE()

private:
    void SetInterface();
    void AddToToolbar(wxToolBar *toolBar, bool checked, const std::wstring &file, int id, const std::wstring &name);

    //! The current editing mode
    Ids  mMode;

    wxToolBar *mToolBar;                //!< The toolbar
    wxMenuItem *mEditMove;              //!< Edit>Move menu item
    wxMenuItem *mEditRotate;            //!< Edit>Rotate menu item
    
    //! True when we are playing an animation
    bool mPlaying;
    
    //! The timeline child window
    CViewTimeline *mViewTimeline;

    //! The editing child window
    CViewEdit *mViewEdit;

    //! The actors child window
    CViewActors *mViewActors;
    
    //! The document we are displaying
    CDocument *mDocument;
    
    //! Pointer to harold bubble object
    CTextBubbleDrawable *mHaroldBubble;
    
    //! Pointer to Sparty bubble object
    CTextBubbleDrawable *mSpartyBubble;
    
    wxTimer mTimer;     //!< Timer to cause redraws
    wxStopWatch mWatch; //!< Stopwatch to keep track of time
    double  mPlayStartTime;  //!< Time we start playing from
};

#endif /* CFRAME_H_ */
