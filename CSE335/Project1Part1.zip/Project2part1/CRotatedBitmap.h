/*!
 * \file CRotatedBitmap.h
 * 
 * Managing rotating a bitmap
 * 
 * \author Charles B. Owen
 * 
 * \brief 
 */

#ifndef CROTATEDBITMAP_H
#define CROTATEDBITMAP_H

/*! \brief A class for managing rotating an bitmap.
 */
class CRotatedBitmap
{
public:
    CRotatedBitmap();
    virtual ~CRotatedBitmap();
    
    
    /*! \brief Get the center point for the image
     * \returns center point for the image
     */
    wxPoint GetCenter() {return mCenter;}

    /*! \brief Set the center point for the image
     * \param center center point for the image
     */
    void SetCenter(wxPoint center) {mCenter = center;}

    /*! \brief Is this bitmap loaded for use?
     * \returns true if loaded
     */
    bool IsLoaded() const {return mLoaded;}

    
    void LoadFile(const std::wstring &filename);
    void DrawBitmap(wxDC *dc, wxPoint position, double angle);


private:
    //! Copy constructor (disabled)
    CRotatedBitmap(const CRotatedBitmap &);
    //! Assignment operator (disabled)
    CRotatedBitmap &operator=(const CRotatedBitmap &);

protected:
    //! The actual image
    wxImage mImage;

    //! Center point for the image
    wxPoint mCenter;

    //! Rotation angle for the bitmap
    double mBitmapR;

    //! Bitmap center point
    wxPoint mBitmapCenter;

    //! The rotated image
    wxImage mRotatedImage;

    //! A bitmap made from the rotated image
    wxBitmap mRotatedBitmap;

    //! True if the bitmap is valid
    bool mRotatedBitmapValid;
    
    //! True if a bitmap is loaded
    bool mLoaded;
};

#endif    /* CROTATEDBITMAP_H */
