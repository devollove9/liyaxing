/*!
 * \file CDocument.h
 * 
 * The main document class
 * 
 * \author Charles B. Owen
 */

#ifndef CDOCUMENT_H
#define	CDOCUMENT_H

#include <list>
#include "CDocumentObserver.h"
#include "CIterator.h"
#include "CTimeline.h"

class CActor;

/*! \brief The document containing the scene to draw.
 */
class CDocument {
public:
    CDocument();
    virtual ~CDocument();
    
    void AddObserver(CDocumentObserver *observer);
    void RemoveObserver(CDocumentObserver *observer);
    void UpdateObservers();
    void Draw(wxDC *dc);
    void AddActor(CActor *actor);
    void SetAnimationTime(double time);
    void SaveAnimation(const std::wstring &filename);
    
    /*! \brief Get the document size
     * \returns Size of the document as a wxSize object */
    wxSize GetSize() const {return mSize;}
    
    /*! \brief Set the document size
     * \param sz Size to set for the document */
    void SetSize(wxSize sz) {mSize = sz;}
    
    /*! \brief Get a pointer to the Timeline object
     * \returns Pointer to the Timeline object
     */
    CTimeline *GetTimeline() {return &mTimeline;}
    
    friend class ActorIterator;
    
    //! \brief An iterator or actors
    class ActorIterator : public CIterator<CActor *>
    {
    public:
        //! \brief Constructor 
        //! \param document The document for this iterator
        ActorIterator(CDocument *document) : mDocument(document)
                {iter = document->mActors.begin();}
        
        virtual void First() {iter = mDocument->mActors.begin();}
        virtual void Next() {iter++;}
        virtual bool IsDone() {iter == mDocument->mActors.end();}
        virtual CActor *Current() {return *iter;}
    
    private:
        CDocument *mDocument;   //!< The document we are iterating over
        std::list<CActor *>::iterator iter;  //!< Current item in document
    };
    
    /*! \brief Get an actor iterator for this document
     * \returns An allocated actor iterator
     */
    ActorIterator *GetActors() {return new ActorIterator(this);}
    double GetAnimationTime();
    void LoadAnimation(const std::wstring &filename);
    
private:
    //! \brief Copy Constructor (Disabled)
    CDocument(const CDocument &);
    //! \brief Assignment Operator (Disabled)
    CDocument &operator=(const CDocument &);
    
    //! The document size
    wxSize  mSize;  
    
    //! The observers of this document
    std::list<CDocumentObserver *> mObservers;
    
    //! Actors for this document
    std::list<CActor *> mActors;
    
    //! The animation timeline
    CTimeline mTimeline;
};

#endif	/* CDOCUMENT_H */

