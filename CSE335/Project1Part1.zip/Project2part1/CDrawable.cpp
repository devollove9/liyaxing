/* 
 * \file CDrawable.cpp
 * \author Charles B. Owen
 */

#include "wx/prec.h"
#include <cmath>
#include "CDrawable.h"
#include "CActor.h"
#include "CTimeline.h"

using namespace std;

/*! \brief Constructor
 * \param name Name of the drawable part
 */
CDrawable::CDrawable(std::wstring name) : mName(name)
{
    mPosition = wxPoint(0, 0);
    mRotation = 0;
    mPlacedPosition = wxPoint(0, 0);
    mPlacedR = 0;
    mActor = NULL;
    mParent = NULL;
}

//! \brief Destructor
CDrawable::~CDrawable()
{
    for(list<CDrawable *>::iterator i=mChildren.begin();
            i!=mChildren.end();  i++)
    {
        delete *i;
    }
    
    mChildren.clear();
}

/*! Add the channels for this drawable to a timeline
 * \param timeline The timeline class.
 */
void CDrawable::SetTimeline(CTimeline *timeline)
{
    timeline->AddChannel(&mChannel);
}

/*! \brief Place the drawables at the correct location. 
 * 
 * This works hierarchically from top item down.
 * \param offset An x,y offset
 * \param rotate A rotation
 */
void CDrawable::Place(wxPoint offset, double rotate)
{
    // Combine the transformation we are given with the transformation
    // for this object.
    mPlacedPosition = offset + RotatePoint(mPosition, rotate);
    mPlacedR = mRotation + rotate;
    
    // Update our children
    for(list<CDrawable *>::iterator d=mChildren.begin(); d!=mChildren.end(); d++)
    {
        (*d)->Place(mPlacedPosition, mPlacedR);
    }
}


/*! \brief Add a child to this drawable
 * \param child Child drawable to add
 */
void CDrawable::AddChild(CDrawable *child)
{
    mChildren.push_back(child);
    child->SetParent(this);
}

/*! \brief Is this drawable movable with the mouse
 * \returns true if movable
 */
bool CDrawable::IsMovable()
{
    return false;
}


/*! \brief Move the drawable by a specified amount in screen coordinates.
 *
 * Corrects so the movement is in local coordinates.
 * \param delta An amount to move in screen coordinates
 */
void CDrawable::Move(wxPoint delta)
{
    if(GetParent() != NULL)
    {
        mPosition += RotatePoint(delta, -GetParent()->mPlacedR);
    }
    else
    {
        mPosition += delta;
    }
}

/*! \brief Rotate a point by a given angle.
 * \param point The point to rotate
 * \param angle An angle in radians
 * \returns Rotated point
 */
wxPoint CDrawable::RotatePoint(wxPoint point, double angle)
{
    double cosA = cos(angle);
    double sinA = sin(angle);

    return wxPoint(cosA * point.x + sinA * point.y,
                  -sinA * point.x + cosA * point.y);
}

/*! \brief Set rotation
 * \param mRotation New value for rotation
 */
void CDrawable::SetRotation(double mRotation) {
    this->mRotation = mRotation;
}

/*! \brief Get rotation
 * \returns rotation
 */
double CDrawable::GetRotation() const {
    return mRotation;
}

/*! \brief Set name
 * \param mName New value for name
 */
void CDrawable::SetName(std::wstring mName) {
    this->mName = mName;
}

/*! \brief Get name
 * \returns name
 */
std::wstring CDrawable::GetName() const {
    return mName;
}

/*! \brief Set position
 * \param mPosition New value for position
 */
void CDrawable::SetPosition(wxPoint mPosition) {
    this->mPosition = mPosition;
}

/*! \brief Get position
 * \returns position
 */
wxPoint CDrawable::GetPosition() const {
    return mPosition;
}

/*! \brief Set the actor for this drawable
 * \param actor The actor we are associated with
 */
void CDrawable::SetActor(CActor *actor)
{
    mActor = actor;
    
    // Set the channel name
    mChannel.SetName(actor->GetName() + L":" + mName);
}


/*! \brief Set the keyframe based on the current status.
 */
void CDrawable::SetKeyframe()
{
    mChannel.SetKeyframe(mRotation);
}

/*! \brief Get the current channel from the animation system.
 */
void CDrawable::GetKeyframe()
{
    if(mChannel.GetNumKeyframes() > 0)
        mRotation = mChannel.GetAngle();
}
