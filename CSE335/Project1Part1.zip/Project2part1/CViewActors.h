/*!
* \file CViewActors.h
*
* This is a scrolled window which displays the names of all
 * actors and gives use the ability to enable and disable them.
*
* \author Charles B. Owen
*/

#pragma once
#ifndef CVIEWACTORS_H_
#define CVIEWACTORS_H_

#include "CDocumentObserver.h"

class CFrame;
class CDrawable;

/*! \brief A View class where we will see our actors.
 */
class CViewActors : public wxScrolledWindow, public CDocumentObserver
{
public:
    CViewActors(CFrame *frame);
    virtual ~CViewActors();

    void OnPaint(wxPaintEvent &event);
    void OnLeftButtonDown(wxMouseEvent &event);
    void UpdateObserver();
    
    int DrawDrawablesNames(wxDC *dc, CDrawable *drawable, int x, int y);

    
    // Notice:  Don't put anything between DECLARE_EVENT_TABLE() and private:
    DECLARE_EVENT_TABLE()

private:
    //! Pointer to the frame that uses this view
    CFrame *mFrame;
    
    int mTextHeight;    //!< The height of text on the screen
};

#endif /* CVIEWACTORS_H_ */
