/*! \file CTextBubble.h
 *
 * This class implements a basic text bubble control.
 *
 * \author Charles B. Owen
 */

#pragma once
#ifndef CTEXTBUBBLE_H_
#define CTEXTBUBBLE_H_

#ifndef _WX_WX_H_
#include <wx/wx.h>
#endif

#include <string>
#include <vector>


/*! Basic text bubble support class
 */
class CTextBubble
{
public:
    CTextBubble();
    virtual ~CTextBubble();

    void DrawMe(wxDC *dc);
    bool IsPointInside(int x, int y);

    /*! Get the text from the bubble
     * \returns Current bubble text string
     */
    std::wstring GetText() const {return mText;}

    void SetText(const std::wstring &str);

    /*! Get the mirror status for the text bubble
     * \returns True if text bubble is mirrored
     */
    bool GetMirror() const {return mMirror;}

    /*! Set the text bubble mirror status
     * \param m Set true if text bubble is mirrored
     */
    void SetMirror(bool m) {mMirror = m;  mNewString = true;}

    /*! Set the bubble position
     * \param x X location
     * \param y Y location
     */
    void SetBubblePosition(int x, int y) {mPosition = wxPoint(x, y);}

    /*! Get the bubble X position
     * \returns X position
     */
    int GetX() const {return mPosition.x;}

    /*! Get the bubble Y position
     * \returns Y position
     */
    int GetY() const {return mPosition.y;}

private:
    void NewString(wxDC *dc);

    bool     mMirror;     //!< Should we mirror the text box?
    std::wstring mText;    //!< The unadulterated text
    wxPoint  mPosition;    //!< Position for the tip of the text bubble
    wxFont   mFont;        //!< Font we will use to draw the text bubble

    bool     mNewString;   //!< Set true when the string changes

    wxImage  mImage;        //!< Text bubble original image
    wxImage  mImageScaled;  //!< Text bubble image scaled to size
    wxBitmap mBitmap;       //!< Text bubble as a bitmap

    //! The array of wxString objects that holds the split text
    std::vector<wxString> mSplitText;
};

#endif /* CTEXTBUBBLE_H_ */
