/*!
 * \file CViewTimeline.cpp
 *
 * \author Charles B. Owen
 */

#include "wx/prec.h"
#include "CViewTimeline.h"
#include "CFrame.h"

//! The window height
const int WindowHeight = 65;

//! The spacing between ticks in the timeline
const int TickSpacing = 3;

//! The length of a short tick mark
const int TickShort = 10;

//! The length of a long tick mark
const int TickLong = 20;

//! The amount of space to leave under the tick marks
const int TickUnder = 10;

//! Space to the left of the scale
const int BorderLeft = 10;

//! Space to the right of the scale
const int BorderRight = 10;

BEGIN_EVENT_TABLE(CViewTimeline, wxScrolledWindow)
   EVT_SIZE(CViewTimeline::OnSize)
   EVT_PAINT(CViewTimeline::OnPaint)
   EVT_SET_FOCUS(CViewTimeline::OnFocus)
   EVT_KEY_DOWN(CViewTimeline::OnKeyDown)
   EVT_LEFT_DOWN(CViewTimeline::OnLeftButtonDown)
   EVT_LEFT_UP(CViewTimeline::OnMouseMove)
   EVT_MOTION(CViewTimeline::OnMouseMove)
 END_EVENT_TABLE()

/*! \brief Constructor for the timeline view.
 * \param frame The frame that is the parent for this window.
 */
CViewTimeline::CViewTimeline(CFrame *frame) :
    wxScrolledWindow(frame, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxHSCROLL | wxSUNKEN_BORDER),
        CDocumentObserver(frame->GetDocument()),
        mFrame(frame)
{
    // This is to force the window to have some space (50 pixels tall)
    SetMinSize(wxSize(100, WindowHeight));
    SetScrollRate(1, 0);
    SetName(L"ViewTimeline");
    
    mMovingPointer = false;
    
    bool loadedOk = mPointer.LoadFile(L"images/pointer.png", wxBITMAP_TYPE_PNG);
    assert(loadedOk);
}


/*! \brief Destructor for the timeline view.
 */
CViewTimeline::~CViewTimeline()
{

}

/*! \brief Handle focus coming to this panel
 * \param event The focus change event
 */
void CViewTimeline::OnFocus(wxFocusEvent &event) 
{
#ifdef CSPEECH
    // Speech-specifics
    speak.Delay(0.8);
    speak << "ViewTimeline" << std::flush;
#endif
    event.Skip();
}


/*! \brief Force an update of this window when the document changes.
 */
void CViewTimeline::UpdateObserver()
{
    Refresh();
}


/*! \brief Handle a draw request for this window.
 * \param event The draw event
 */
void CViewTimeline::OnPaint(wxPaintEvent &event)
{
    // Create a device context
    wxPaintDC dc(this);

    // Get the timeline
    CTimeline *timeline = GetDocument()->GetTimeline();

    // Set the scroll system correctly
    SetVirtualSize(timeline->GetNumFrames() * TickSpacing + BorderLeft + BorderRight, WindowHeight);


    // Offset the device context due to any scrolling
    DoPrepareDC(dc);

    // Get window dimensions
    int wid, hit;
    GetClientSize(&wid, &hit);

    wxPen tickPen(*wxBLACK, 1);
    dc.SetPen(tickPen);

    wxFont tickFont(8, wxFONTFAMILY_SWISS, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL);
    dc.SetFont(tickFont);

    for(int i=0;  i<=timeline->GetNumFrames(); i++)
    {
        int x = BorderLeft + i * TickSpacing;
        int tickNum = i;

        bool evenSecond = i % timeline->GetFrameRate() == 0;
        int tickLen = evenSecond ? TickLong : TickShort;
        dc.DrawLine(x, hit - TickUnder, x, hit - TickUnder - tickLen);

        if(evenSecond)
        {
            wxString num;
             num.Printf(L"%d", tickNum / timeline->GetFrameRate());
             wxCoord tw, th;
             dc.GetTextExtent(num, &tw, &th);

             dc.DrawText(num, x-tw/2, hit - TickUnder - TickLong - th);
        }
    }

    int px = BorderLeft + TickSpacing * timeline->GetCurrentTime() * timeline->GetFrameRate();
    dc.DrawBitmap(mPointer, px-5, hit - TickUnder - 10, true);

    dc.SetPen(wxNullPen);
    dc.SetBrush(wxNullBrush);
    dc.SetFont(wxNullFont);
}

/*! \brief Handle a left button mouse press event
 * \param event The mouse event
 */
void CViewTimeline::OnLeftButtonDown(wxMouseEvent &event)
{
    // Get the view point start and add to the mouse position
    // to determine where we clicked in the scrolled area.
    int x, y;
    GetViewStart(&x, &y);
    x += event.m_x;
    y += event.m_y;

    // Get the timeline
    CTimeline *timeline = GetDocument()->GetTimeline();
    int pointerX = timeline->GetCurrentTime() * timeline->GetFrameRate() * TickSpacing + BorderLeft;

    mMovingPointer = x >= pointerX - mPointer.GetWidth() / 2 && x <= pointerX + mPointer.GetWidth() / 2;
}




/*! \brief Handle a mouse move event
 * \param event The mouse event
 */
void CViewTimeline::OnMouseMove(wxMouseEvent &event)
{
    if(event.m_leftDown && mMovingPointer)
    {
        // Get the view point start and add to the mouse position
        // to determine where we clicked in the scrolled area.
        int x, y;
        GetViewStart(&x, &y);
        x += event.m_x;
        y += event.m_y;

        // Get the timeline
        CTimeline *timeline = GetDocument()->GetTimeline();
        double time = double(x - BorderLeft) / TickSpacing / timeline->GetFrameRate();
        if(time < 0)
            time = 0;
        else if(time > timeline->GetDuration())
            time = timeline->GetDuration();

        GetDocument()->SetAnimationTime(time);
    }
    else
    {
        mMovingPointer = false;
    }
}




/*! \brief Handle a keypress in this window
 * \param event The keypress event
 */
void CViewTimeline::OnKeyDown(wxKeyEvent &event)
{
    switch(event.GetKeyCode()) 
    {
    case WXK_LEFT:
        break;
        
    case WXK_RIGHT:
        break;
        
    default:
        event.Skip();
        break;
    }

}