/*!
 * \file CIterator.h
 *
 * Base class for general iterators.
 *
 * \author Charles B. Owen
 */

#pragma once
#ifndef CITERATOR_H_
#define CITERATOR_H_

#include <cstdlib>

/*! \brief Base class for iterators.
 */
template<class T> class CIterator
{
public:
    //! \brief Destructor
    virtual ~CIterator() {}

    //! \brief Set to the first location in the collection
    virtual void First() = 0;

    //! \brief Advance to the next location in the collection
    virtual void Next() = 0;

    //! \brief Determine if we reached the end of the collection
    //! \returns true if at end of collection
    virtual bool IsDone() = 0;

    //! \brief Return the current item in the collection
    //! \returns Current item in collection
    virtual T Current() = 0;
};

/*! \brief Iterator smart pointer
 */
template <class T> class CIteratorPtr
{
public:
    //! \brief Constructor
    //! \param i Iterator we are pointing at
    CIteratorPtr(CIterator<T> * i) : mIter(i) {}

    //! \brief Destructor
    virtual ~CIteratorPtr() {delete mIter;}

    //! \brief Overloaded -> operator, allows use to use as a pointer
    //! \returns Iterator we are pointing at
    CIterator<T> *operator->() {return mIter;}

    //! \brief Overloaded * operator, allows us to use dereferenced
    //! \returns Reference to iterator we are pointing at
    CIterator<T> &operator*() {return *mIter;}

private:
    //! \brief Default constructor (disabled)
    CIteratorPtr();
    
    //! \brief Copy constructor (disabled)
    CIteratorPtr(const CIteratorPtr *);

    //! \brief Assignment operator (disabled)
    CIteratorPtr &operator=(CIteratorPtr &);

    //! The pointer to the actual iterator
    CIterator<T> *mIter;
};

//! \brief General purpose null iterator
template <class T> class CNullIterator : public CIterator<T>
{
public:
    //! \brief Set to the first location in the collection
    virtual void First() {}

    //! \brief Advance to the next location in the collection
    virtual void Next() {}

    //! \brief Determine if we reached the end of the collection
    //! \returns true if at end of collection
    virtual bool IsDone() {return true;}

    //! \brief Return the current item in the collection
    //! \returns Current item in the collection
    virtual T Current() {return NULL;}
};


#endif /* CITERATOR_H_ */
