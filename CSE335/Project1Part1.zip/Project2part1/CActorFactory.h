/*!
 * \file CActorFactory.h
 * 
 * The actor factory
 * 
 * \author Charles B. Owen
 */

#ifndef CACTORFACTORY_H
#define	CACTORFACTORY_H


class CTextBubbleDrawable;
class CActor;

/*! \brief Factory that creates actor objects
 */
class CActorFactory 
{
public:
    virtual ~CActorFactory();
    
    //! \brief Create an actor 
    //! \returns Pointer to created actor
    virtual CActor *Create() = 0;
    
    /*! \brief Get a pointer to a text bubble drawable if one is used
     * \returns Pointer to text bubble or null if not supplied
     */
    CTextBubbleDrawable *GetTextBubble() const {return mTextBubble;}
   
protected:
    //! Any text bubble associated with this actor
    CTextBubbleDrawable *mTextBubble;

    CActorFactory();
        
private:
    //! \brief Copy constructor (disabled)
    CActorFactory(const CActorFactory &);

    //! \brief Assignment operator (disabled)
    CActorFactory &operator=(const CActorFactory &);
    
};

#endif	/* CACTORFACTORY_H */

