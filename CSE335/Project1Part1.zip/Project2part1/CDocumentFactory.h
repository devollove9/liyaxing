/*!
 * \file CDocumentFactory.h
 * 
 * This class creates a document.
 * 
 * \author Charles B. Owen
 */
#ifndef CDOCUMENTFACTORY_H
#define	CDOCUMENTFACTORY_H

#include "CDocument.h"

class CTextBubbleDrawable;

/*! \brief Factory class that creates a document
 */
class CDocumentFactory
{
public:
    CDocumentFactory();
    virtual ~CDocumentFactory();

    CDocument *Create();
   
    /** \brief Get Harold text bubble 
     * \returns Text bubble drawable 
     */
    CTextBubbleDrawable *GetHaroldBubble() {return mHaroldBubble;}
    
    /** \brief Get Sparty text bubble 
     * \returns Text bubble drawable 
     */
    CTextBubbleDrawable *GetSpartyBubble() {return mSpartyBubble;}

private:
    //! \brief Copy constructor (disabled)
    CDocumentFactory(const CDocumentFactory &);

    //! \brief Assignment operator (disabled)
    CDocumentFactory &operator=(const CDocumentFactory &);
    
    //! A text bubble for Harold
    CTextBubbleDrawable *mHaroldBubble;
    
    //! A text bubble for Sparty
    CTextBubbleDrawable *mSpartyBubble;
};

#endif	/* CDOCUMENTFACTORY_H */

