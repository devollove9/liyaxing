/*!
 * \file CTextBubble.h
 *
 * This is a dialog box for editing the status of a text bubble. It allows you to
 * set the mirrored status and the text.
 *
 * \author Charles B. Owen
 */


#pragma once
#ifndef CTEXTBUBBLEDLG_H_
#define CTEXTBUBBLEDLG_H_

#ifndef _WX_WX_H_
#include <wx/wx.h>
#endif

#include "CTextBubble.h"

/*! This is a dialog box for editing the status of a text bubble. It allows you to
 * set the mirrored status and the text.
 */
class CTextBubbleDlg : public wxDialog
{
public:
    CTextBubbleDlg(wxWindow *parent, CTextBubble *bubble);
    virtual ~CTextBubbleDlg();

    //! Id values for our controls
    enum Ids {ID_Ok, ID_Cancel};

    void OnOkButton(wxCommandEvent &event);
    void OnCancelButton(wxCommandEvent &event);

    // Don't put anything between this line and the next
    // private, protected, or public.
    DECLARE_EVENT_TABLE()

private:
    CTextBubbleDlg();

    CTextBubble *mBubble;       //!< Pointer to the text bubble we are editing
    wxButton *mOkButton;        //!< Okay button object pointer
    wxButton *mCancelButton;    //!< Cancel button object pointer
    wxTextCtrl *mTextCtrl;      //!< Text editing object pointer
    wxCheckBox *mMirrorCtrl;    //!< Checkbox for mirroring object pointer
};

#endif /* CTEXTBUBBLEDLG_H_ */
