/*!
 * \file CAnimChannel.cpp
 *
 * \author Charles B. Owen
 */

#include "wx/prec.h"
#include "CAnimChannel.h"
#include "CTimeline.h"

/*! \brief Constructor 
 */
CAnimChannel::CAnimChannel()
{
    mKeyframe1 = -1;
    mKeyframe2 = -1;
    mTimeline = NULL;
}

/*! \brief Destructor 
 */
CAnimChannel::~CAnimChannel()
{
    
}


/*! \brief Create an XML node that saves the animation channel
 * \returns Pointer to a newly allocated node
 */
wxXmlNode *CAnimChannel::XmlSave()
{
    // Create a new node for the tile
    wxXmlNode *node = new wxXmlNode(wxXML_ELEMENT_NODE, L"channel");

    node->AddAttribute(L"name", mName.c_str());

    return node;
}



/*! \brief Determine how we should insert a keyframe into our keyframe list.
 * \returns The insert action
 */
CAnimChannel::InsertActions CAnimChannel::GetInsertAction()
{
    int currFrame = GetTimeline()->GetCurrentFrame();

    if(mKeyframe1 < 0)
    {
        if(mKeyframe2 < 0)
            return Append;
        else
            return Insert;
    }

    // We know mKeyframe1 is valid
    int frame1 = GetKeyframe(mKeyframe1)->GetFrame();

    if(mKeyframe2 < 0)
    {
        if(frame1 < currFrame)
            return Append;
        else
            return Replace;
    }

    if(frame1 < currFrame)
        return Insert;
    else
        return Replace;
}


/*! \brief Ensure the keyframe indices are valid for the current time.
 *
 * The location pointed to by keyframe1 must be a time less than or
 * equal to the current time and the location pointed to by keyframe2
 * must be the next location and a location greater than the current
 * time. Note that the time may be before or after the first or last
 * item in the list.  We indicate that with values of -1 for the
 * indices.
 */
void CAnimChannel::SetKeyframeIndices()
{
    int currFrame = GetTimeline()->GetCurrentFrame();

    // Should we move forward in time?
    while(mKeyframe2 >= 0 && GetKeyframe(mKeyframe2)->GetFrame() <= currFrame)
    {
        mKeyframe1 = mKeyframe2;
        mKeyframe2++;
        if(mKeyframe2 >= GetNumKeyframes())
            mKeyframe2 = -1;
    }

    // Should we move backwards in time?
    while(mKeyframe1 >= 0 && GetKeyframe(mKeyframe1)->GetFrame() > currFrame)
    {
        mKeyframe2 = mKeyframe1;
        mKeyframe1--;
    }
}


/*! \brief Clear the current keyframe.
 */
void CAnimChannel::ClearKeyframe()
{
    // If there is no keyframe1, we are not on a keyframe
    if(mKeyframe1 < 0)
        return;

    // We know mKeyframe1 is valid
    // Determine the frame number for the first keyframe
    int frame1 = GetKeyframe(mKeyframe1)->GetFrame();

   // What is the current frame?
    int currFrame = GetTimeline()->GetCurrentFrame();

    // This is only valid if we are on a keyframe, as
    // indicated by mKeyframe1 equal to the current frame.
    if(frame1 != currFrame)
        return;

    DeleteKeyframe(mKeyframe1);

    // The current frame becomes the previous frame
    // or -1 if we are on frame 0
    mKeyframe1--;

    // If the next frame is valid, it will be decreased by 1
    if(mKeyframe2 >= 0)
        mKeyframe2--;

}


/*! \brief Save a keyframe to an xml node.
 * \returns The new keyframe node
 */
wxXmlNode *CAnimChannel::Keyframe::XmlSave()
{
    // Create a new node for the keyframe
    wxXmlNode *node = new wxXmlNode(wxXML_ELEMENT_NODE, L"keyframe");

    node->AddAttribute(L"frame", wxString::Format(L"%d", mFrame));

    return node;
}



/*! \brief Clear the animation channel.
 */
void CAnimChannel::Clear()
{
    // Clear the two keyframe indices
    mKeyframe1 = -1;
    mKeyframe2 = -1;
}


/*! \brief Load animation channel data from a file.
 * \param node The node to load from
 */
void CAnimChannel::XmlLoad(wxXmlNode *node)
{
    // After we have loaded the data (in a derived class)
    // we need to set mKeyframe1 and mKeyframe2 to the
    // correct values for an animation time of zero.
    // This took some thought.
    if(GetNumKeyframes() == 0)
    {
        // If no keyframes, then the keyframe indices
        // point to nothing
        mKeyframe1 = -1;
        mKeyframe2 = -1;
        return;
    }

    if(GetNumKeyframes() == 1)
    {
        // If there is one keyframe, we are either before or at
        // the first keyframe. When loading, the animation time is
        // set to zero.
        if(GetKeyframe(0)->GetFrame() > 0)
        {
            mKeyframe1 = -1;
            mKeyframe2 = 0;
        }
        else
        {
            mKeyframe1 = 0;
            mKeyframe2 = -1;
        }

        return;
    }

    // We have two or more keyframes. We may be before
    // the first keyframe, or at the first keyframe
    if(GetKeyframe(0)->GetFrame() > 0)
    {
        mKeyframe1 = -1;
        mKeyframe2 = 0;
    }
    else
    {
        mKeyframe1 = 0;
        mKeyframe2 = 1;
    }
}

/*! \brief Load the XML node for a keyframe.
 * \param  node the XML node containing the keyframe data
 */
void CAnimChannel::Keyframe::XmlLoad(wxXmlNode *node)
{
    mFrame = wcstol(node->GetAttribute(L"frame", L"0"), NULL, 10);
}
