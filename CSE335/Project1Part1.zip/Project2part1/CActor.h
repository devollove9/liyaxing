/*!
 * \file CActor.h
 * 
 * Class that describes an actor in our animation system
 * 
 * \author Charles B. Owen
 */

#ifndef CACTOR_H
#define	CACTOR_H

#include <list>
#include "CDrawable.h"
#include "CAnimChannelPoint.h"

class CDocument;

/*! \brief Class that manages an actor
 */
class CActor
{
public:

    virtual ~CActor();
    
    CActor(const std::wstring &name);
    void SetRoot(CDrawable *root);
    void Draw(wxDC *dc);
    CDrawable *HitTest(wxPoint pos);
    void AddDrawable(CDrawable *drawable);
    
    void SetClickable(bool mClickable);
    bool IsClickable() const;
    void SetPosition(wxPoint mPosition);
    wxPoint GetPosition() const;
    void SetEnabled(bool mEnabled);
    bool IsEnabled() const;
    void SetName(std::wstring mName);
    std::wstring GetName() const;

    void SetDocument(CDocument *doc);
    
    void SetKeyframe();
    void GetKeyframe();
    
    /*! \brief Get the root drawable
     * \returns The root drawable
     */
    CDrawable *GetRoot() {return mRoot;}
    
    
private:
    //! \brief Default constructor (disabled)
    CActor();
    
    //! \brief Copy constructor (disabled)
    CActor(const CActor&);
    
    //! \brief Assignment operator (disabled)
    CActor &operator=(const CActor &);
    
    std::wstring mName; //!< The actor name
    bool mEnabled;      //!< Is this actor enabled?
    wxPoint mPosition;  //!< Location of this actor
    bool mClickable;    //!< Is this actor clickable?    
    
    //! The root drawable
    CDrawable *mRoot;
    
    //! The drawables in drawing order
    std::list<CDrawable *> mDrawablesInOrder;
    
    //! The document this actor is associated with
    CDocument *mDocument;
    
    //! The actor position channel
    CAnimChannelPoint mChannel;
};

#endif	/* CACTOR_H */

