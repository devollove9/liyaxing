/* 
 * \file CWxTest.h
 * \author Charles B. Owen
 *
 * Support for unit testing of wxWidgets applications.
 */

#ifndef CWXTEST_H
#define	CWXTEST_H

#include "CApp.h"
#include <list>

/*! \brief wxWidgets testing handler
 * 
 * This class supports unit testing of wxWidgets
 * applications. It will start the application and then
 * run tests at delayed points in time. 
 */
class CWxTest : public wxEvtHandler
{
public:
    CWxTest(); 
    virtual ~CWxTest();
    
    void AddTest(int delay, void (*test)());
    int Start(int argc, char** argv);
    void OnTimer(wxTimerEvent &event);
    
    static CApp *GetApp();
    static CFrame *GetFrame();
    
    DECLARE_EVENT_TABLE()
        
private:
    //! \brief Copy constructor (disabled)
    CWxTest(const CWxTest& orig);
    void StartTimer();
    
    //! \brief Nested struct to store
    //! scheduled tests
    struct Test
    {
        int mTime;              //!< Time of the test
        void (*mTest)();        //!< The test function
        
        //! \brief Less than operator
        //! Compares based on delay time.
        //! \param t other object to compare to
        //! \returns true if this object less than T
        bool operator<(const Test &t) {return mTime < t.mTime;}
    };
    
    wxTimer *mTimer;            //!< The timer we use
    int      mTime;             //!< The time for the current test
    std::list<Test> mTests;     //!< The list of scheduled tests
};

#endif	/* CWXTEST_H */

