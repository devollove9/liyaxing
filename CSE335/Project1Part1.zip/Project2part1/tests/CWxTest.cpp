/* 
 * \file CWxStart.cpp
 * \author Charles B. Owen
 */

#include "../wx/prec.h"
#include <algorithm>
#include "CWxTest.h"
#include "CApp.h"
#include "CFrame.h"

BEGIN_EVENT_TABLE(CWxTest, wxEvtHandler)
    EVT_TIMER(1, CWxTest::OnTimer)
END_EVENT_TABLE()
   
//! External reference to wxGetApp function
CApp &wxGetApp();

/*! \brief Constructor
 * We cannot create the timer when this object is 
 * created, since wxWidgets is not yet initialized.
 */
CWxTest::CWxTest()
{
    mTimer = NULL;
    mTime = 0;
}

/*! \brief Destructor
 */
CWxTest::~CWxTest()
{
    delete mTimer;
}

/*! \brief Get a pointer to the application object
 * \returns Pointer to CApp object
 */
CApp *CWxTest::GetApp() 
{
    return &wxGetApp();
}

/*! \brief Get a pointer to the main frame
 * \returns Pointer to CFrame object
 */
CFrame *CWxTest::GetFrame()
{
    return GetApp()->GetFrame();
}
    
/*! \brief Add a test
 * 
 * This function adds a test that will occur at a later
 * point in time. The test will consist of calling a global
 * function as provided.
 * 
 * \param time The time of the test in milliseconds
 * \param test The test function to call
 */
void CWxTest::AddTest(int time, void (*test)())
{
    Test t;
    t.mTime = time;
    t.mTest = test;
    mTests.push_back(t);
}
    
/*! \brief Start the wxWidgets application for testing
 * 
 * This will start the application and set a timer to
 * run future tests. This does not return until the application 
 * terminates. A close on the main frame will occur one
 * second after the last test is run.
 * 
 * \param argc Normal program argument count
 * \param argv Normal program argument list
 * \returns 0 after the application terminates
 */
int CWxTest::Start(int argc, char** argv)
{
    if(!mTests.empty()) 
    {
        // If we have tests, sort them and create
        // an event one second after the last one
        mTests.sort();
        AddTest(mTests.back().mTime + 1000, NULL);
    }
    else
    {
        // Otherwise, just create an event in one second
        AddTest(1000, NULL);
    }
    
    // This starts up wxWidgets
    wxEntryStart(argc, argv);
    
    // Call the application init function
    CApp *app = &wxGetApp();
    app->CallOnInit();
          
    // Create the timer and start any needed timer
    // for a future test.
    mTimer = new wxTimer(this, 1);
    
    StartTimer();
    
    // Run the application
    app->OnRun();
    
    // Cleanup since we are done
    wxEntryCleanup();
    return 0;
}

/*! \brief Start the timer
 * 
 * This will start the timer and set it to the 
 * time remaining until the next scheduled test.
 */
void CWxTest::StartTimer() 
{
    mTimer->Start(mTests.front().mTime - mTime);
}

/*! \brief Handle a timer event
 * 
 * This stops the timer and sets the time to the
 * time of the first scheduled test in the list.
 * If there is a test there, it runs it. Then it
 * pops the list and either sends a close to the 
 * main frame if it is done or starts the timer if 
 * there is a future test still pending.
 * 
 * \param event The timer event
 */
void CWxTest::OnTimer(wxTimerEvent &event) 
{
    mTimer->Stop();
    mTime = mTests.front().mTime;
    
    // Do the test if we have it
    if(mTests.front().mTest != NULL)
    {
        (*mTests.front().mTest)();
    }

    mTests.pop_front();
    if(!mTests.empty()) 
    {
        // We have more tests
        StartTimer();
    }
    else 
    {
        // Tests are all done
        delete mTimer;
        mTimer = NULL;

        CApp *app = &wxGetApp();
        app->GetFrame()->Close();
    }

}