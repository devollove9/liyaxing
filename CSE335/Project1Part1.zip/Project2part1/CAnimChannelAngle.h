/*!
 * \file CAnimChannelAngle.h
 *
 * An animation channel specific to angles
 *
 * \author Charles B. Owen
 */

#pragma once
#ifndef CANIMCHANNELANGLE_H_
#define CANIMCHANNELANGLE_H_

#include <vector>
#include "CAnimChannel.h"

/*! \brief An animation channel specific to angles
 */
class CAnimChannelAngle: public CAnimChannel
{
public:
    CAnimChannelAngle();
    virtual ~CAnimChannelAngle();

    /*! \brief Angle channel nested class
     */
    class KeyframeAngle : public Keyframe
    {
    public:
        /*! \brief Get the angle for this keyframe
         * \returns Keyframe angle
         */
        double GetAngle() const {return mAngle;}

        /*! \brief Set the angle for this keyframe
         * \param a New keyframe angle
         */
        void SetAngle(double a) {mAngle = a;}
        
        wxXmlNode *XmlSave();
        void XmlLoad(wxXmlNode *node);

    private:
        //! The angle for this keyframe
        double mAngle;
    };

        
    int GetNumKeyframes();
    Keyframe *GetKeyframe(int frame);
    void SetKeyframe(double angle);
    double GetAngle();
    void DeleteKeyframe(int k);
    wxXmlNode *XmlSave();
    void Clear();
    void XmlLoad(wxXmlNode *node);
        
private:
    //! \brief Copy constructor (disabled)
    CAnimChannelAngle(const CAnimChannelAngle &);
    //! \brief Assignment operator (disabled)
    CAnimChannelAngle &operator=(const CAnimChannelAngle &);

    //! The keyframes list
    std::vector<KeyframeAngle> mKeyframes;
};

#endif /* CANIMCHANNELANGLE_H_ */
