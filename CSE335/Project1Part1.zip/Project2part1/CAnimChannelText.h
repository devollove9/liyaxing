/*!
 * \file CAnimChannelText.h
 *
 * An animation channel specific to points (movement)
 *
 * \author Charles B. Owen
 */

#pragma once
#ifndef CANIMCHANNELTEXT_H_
#define CANIMCHANNELTEXT_H_

#include <vector>
#include <string>
#include "CAnimChannel.h"

/*! \brief An animation channel specific to points (movement)
 */
class CAnimChannelText: public CAnimChannel
{
public:
    CAnimChannelText();
    virtual ~CAnimChannelText();

    /*! \brief Nested class that describes a single keyframe for text channels
     */
    class KeyframeText : public Keyframe
    {
    public:
        /*! Get the keyframe text
         * \returns keyframe text
         */
        std::wstring GetText() {return mText;}
        
        /*! Get the mirrored state
         * \returns true if mirrored
         */
        bool GetMirror() {return mMirror;}
        
         /*! Set the keyframe text
         * \param str New keyframe text
         */
        void SetText(const std::wstring &str) {mText = str;}
        
        /*! Set the mirror state
         * \param m New mirror state, true if mirrored
         */
        void SetMirror(bool m) {mMirror = m;}
        
        wxXmlNode *XmlSave();
        void XmlLoad(wxXmlNode *node);

    private:
        //! The text for the keyframe
        std::wstring mText;
        
        //! The mirror state for the keyframe
        bool mMirror;
    };

    int GetNumKeyframes();
    Keyframe *GetKeyframe(int frame);
    void SetKeyframe(const std::wstring &str, bool mirror);
    std::wstring GetText();
    bool GetMirror();
    void DeleteKeyframe(int k);
    wxXmlNode *XmlSave();
    void Clear();
    void XmlLoad(wxXmlNode *node);
    
private:
    //! List of point keyframes for the channel
    std::vector<KeyframeText> mKeyframes;};

#endif /* CANIMCHANNELTEXT_H_ */
