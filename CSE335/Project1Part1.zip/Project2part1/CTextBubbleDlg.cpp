/*
 * Name:     CTextBubbleDlg.cpp
 * This is a dialog box for editing the status of a text bubble. It allows you to
 * set the mirrored status and the text.
 *
 * Class:    CTextBubbleDlg
 * Header:   CTextBubbleDlg.h
 * Created : Feb 28, 2010
 * Author :  Charles B. Owen
 */

#include "CTextBubbleDlg.h"

using namespace std;


/*! Constructor for a text bubble dialog box. Creates the dialog box.
 * \param parent a parent window for the box
 * \param bubble The bubble we are editing
 */
CTextBubbleDlg::CTextBubbleDlg(wxWindow *parent, CTextBubble *bubble) :
    wxDialog(parent, wxID_ANY, L"Text Bubble", wxDefaultPosition, wxDefaultSize, wxDEFAULT_DIALOG_STYLE),
    mBubble(bubble)
{
    // Create a vertical sizer so we have a top part of the box
    // for the options and a bottom part for the Ok and Cancel buttons
    wxBoxSizer* vSizer;
    vSizer = new wxBoxSizer( wxVERTICAL );

    wxStaticBoxSizer *boxSizer = new wxStaticBoxSizer(wxVERTICAL, this, L"Text");
    vSizer->Add(boxSizer, 1, wxALL | wxEXPAND);

    mTextCtrl = new wxTextCtrl(this, wxID_ANY, bubble->GetText().c_str(), wxDefaultPosition, wxDefaultSize, wxTE_MULTILINE | wxTE_WORDWRAP);
    mTextCtrl->SetMinSize(wxSize(200, 75));
    boxSizer->Add(mTextCtrl, 1, wxALL | wxEXPAND);

    mMirrorCtrl = new wxCheckBox(this, wxID_ANY, L"Mirrored", wxDefaultPosition, wxDefaultSize);
    mMirrorCtrl->SetValue(bubble->GetMirror());
    vSizer->Add(mMirrorCtrl, 0, wxALL | wxEXPAND);

    // Create a horizontal sizer that will hold the Ok and Cancel buttons
    // and add it to the vertical sizer.
    wxBoxSizer *hSizer;
    hSizer = new wxBoxSizer(wxHORIZONTAL);
    vSizer->Add(hSizer, 0, wxALL | wxEXPAND);

    // Create an Ok button and add it to the horizontal sizer.
    mOkButton = new wxButton( this, ID_Ok, L"Ok", wxDefaultPosition, wxDefaultSize, 0 );
    hSizer->Add(mOkButton, 1, wxALL | wxEXPAND);
    mOkButton->SetDefault();

    // Create a Cancel button and add to the horizontal sizer
    mCancelButton = new wxButton( this, ID_Cancel, L"Cancel", wxDefaultPosition, wxDefaultSize, 0 );
    hSizer->Add(mCancelButton, 1, wxALL | wxEXPAND);


    // Set the top level sizer and force the window to match the size
    this->SetSizer( vSizer );
    this->Layout();
    vSizer->Fit( this );

    mTextCtrl->SetFocus();
}

/*! Destructor. Doesn't do anything, actually.
 */
CTextBubbleDlg::~CTextBubbleDlg()
{
}



/*! Handle an Ok button press.
 * \param event The command event
 */
void CTextBubbleDlg::OnOkButton(wxCommandEvent &event)
{
    wstring text = mTextCtrl->GetValue().wc_str();
    mBubble->SetText(text);
    mBubble->SetMirror(mMirrorCtrl->GetValue());
    EndModal(wxOK);
}


/*! Handle a Cancel button press.
 * \param event The command event
 */
void CTextBubbleDlg::OnCancelButton(wxCommandEvent &event)
{
    EndModal(wxCANCEL);
}


BEGIN_EVENT_TABLE(CTextBubbleDlg, wxDialog)
    EVT_BUTTON(ID_Ok, CTextBubbleDlg::OnOkButton)
    EVT_BUTTON(ID_Cancel, CTextBubbleDlg::OnCancelButton)
END_EVENT_TABLE()
