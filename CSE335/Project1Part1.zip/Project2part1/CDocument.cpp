/* 
 * \file CDocument.cpp
 * \author Charles B. Owen
 */

#include "wx/prec.h"
#include "CDocument.h"
#include "CActor.h"

using namespace std;

CDocument::CDocument() {
    // Initialize mSize
    mSize = wxSize(800, 600);
}


/*! \brief CDocument destructor
 */
CDocument::~CDocument() 
{
    for(list<CActor *>::iterator a=mActors.begin(); a!=mActors.end(); a++)
    {
        delete *a;
    }

    mActors.clear();
}

/*! \brief Save the animation as a file.
 * \param filename File to save the animation to.
 */
void CDocument::SaveAnimation(const std::wstring &filename)
{
    mTimeline.Save(filename);
}

/*! \brief Load the animation from a file.
 * \param filename File to load the animation from
 */
void CDocument::LoadAnimation(const std::wstring &filename)
{
    mTimeline.Load(filename);
    SetAnimationTime(0);
}


/*! \brief Add an actor to this document
 * \param actor Actor to add
 */
void CDocument::AddActor(CActor *actor) 
{
    mActors.push_back(actor);
    actor->SetDocument(this);
}


/*! \brief Add an observer to this document.
 * \param observer The observer to add
 */
void CDocument::AddObserver(CDocumentObserver *observer)
{
    mObservers.push_back(observer);
}

/*! \brief Remove an observer from this document
 * \param observer The observer to remove
 */
void CDocument::RemoveObserver(CDocumentObserver *observer)
{
    mObservers.remove(observer);
}

/*! \brief Update all observers to indicate the document has changed.
 */
void CDocument::UpdateObservers()
{
    for(list<CDocumentObserver *>::iterator o=mObservers.begin(); o!=mObservers.end(); o++)
    {
        (*o)->UpdateObserver();
    }
}

/*! \brief Draw the actors
 * \param dc The device context to draw on
 */
void CDocument::Draw(wxDC *dc)
{
    for(list<CActor *>::iterator a=mActors.begin(); a!=mActors.end(); a++)
    {
        CActor *actor = *a;
        actor->Draw(dc);
    }   
}

/*! \brief Set the current animation time
 * 
 * This forces the animation of all
 * objects to the current animation location.
 * \param time The new time.
 */
void CDocument::SetAnimationTime(double time)
{
    mTimeline.SetCurrentTime(time);
    UpdateObservers();
    
    // Update actors to this time.
    for(list<CActor *>::iterator a=mActors.begin(); a!=mActors.end(); a++)
    {
        CActor *actor = *a;
        actor->GetKeyframe();
    }
}


/*! \brief Get the current animation time.
 * \returns The current animation time
 */
double CDocument::GetAnimationTime()
{
    return mTimeline.GetCurrentTime();
}
