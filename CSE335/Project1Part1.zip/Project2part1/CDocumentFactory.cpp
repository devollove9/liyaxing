/* 
 * File:   CDocumentFactory.cpp
 * Author: cbowen
 * 
 * Created on October 13, 2013, 12:55 PM
 */

#include "wx/prec.h"
#include "CDocumentFactory.h"
#include "CHaroldFactory.h"
#include "CSpartyFactory.h"
#include "CActor.h"
#include "CImageDrawable.h"

//! \brief Default constructor
CDocumentFactory::CDocumentFactory() 
{
    mHaroldBubble = NULL;
    mSpartyBubble = NULL;
}

//! \brief Destructor
CDocumentFactory::~CDocumentFactory() {
}

/*! Factory method to create a new document.
 * \returns The created document
 */
CDocument *CDocumentFactory::Create()
{
    CDocument *document = new CDocument();
    
    // Create the background and add it
    CActor *background = new CActor(L"Background");
    background->SetClickable(false);
    background->SetPosition(wxPoint(-100, 0));
    CImageDrawable *backgroundI = new CImageDrawable(L"Background", L"images/Background.png");
    background->AddDrawable(backgroundI);
    background->SetRoot(backgroundI);
    document->AddActor(background); 
    
    // Create and add Harold
    CHaroldFactory factory;
    CActor *harold = factory.Create();
    mHaroldBubble = factory.GetTextBubble();

    // This is where Harold will start out.
    harold->SetPosition(wxPoint(400, 500));

    document->AddActor(harold);
    
    // Create and add Sparty
    CSpartyFactory sfactory;
    CActor *sparty = sfactory.Create();
    mSpartyBubble = sfactory.GetTextBubble();
 
    sparty->SetPosition(wxPoint(200, 500));
    document->AddActor(sparty);

    return document;
}