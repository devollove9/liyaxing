/*!
 * \file CPolyDrawable.h
 * 
 * Class for a drawable consisting of polygons
 * 
 * \author Charles B. Owen
 */
#ifndef CPOLYDRAWABLE_H
#define	CPOLYDRAWABLE_H

#include <vector>
#include "CDrawable.h"

/*! \brief Class for a drawable consisting of polygons
 */
class CPolyDrawable : public CDrawable
{
public:
    CPolyDrawable(const std::wstring &name);
    virtual ~CPolyDrawable();
    void SetColor(wxColour mColor);
    wxColour GetColor() const;
    
    virtual void Draw(wxDC *dc);
    virtual bool HitTest(wxPoint pos);
    void AddPoint(wxPoint point);
    
private:
    //! \brief Default constructor (disabled)
    CPolyDrawable();

    //! \brief Copy constructor (disabled)
    CPolyDrawable(const CPolyDrawable &);

    //! \brief Assignment operator (disabled)
    CPolyDrawable &operator=(const CPolyDrawable &);
    
    
    wxColour    mColor;                 //!< The color we draw
    
    std::vector<wxPoint> mPoints;       //!< Polygon vertices
};

#endif	/* CPOLYDRAWABLE_H */

