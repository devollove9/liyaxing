/*!
 * \file CAnimChannelText.cpp
 *
 * \author Enter_your_name_here
 */

#include "wx/prec.h"
#include "CAnimChannelText.h"
#include "CTimeline.h"

/**
 * \brief Default constructor
 */
CAnimChannelText::CAnimChannelText()
{
}

/**
 * \brief Destructor
 */
CAnimChannelText::~CAnimChannelText()
{
}



/*! \brief Obtain the number of keyframes.
 *
 * This is the size of the keyframe list.
 * \returns Number of keyframes.
 */
int CAnimChannelText::GetNumKeyframes()
{
    return (int)mKeyframes.size();
}


/*! \brief Get a keyframe by index from the list of keyframes.
 * \param frame The frame index
 * \returns Pointer to keyframe at that index.
 */
CAnimChannel::Keyframe *CAnimChannelText::GetKeyframe(int frame)
{
    return &mKeyframes[frame];
}


/*! \brief Delete a keyframe at k.
 * \param k The keyframe to delete
 */
void CAnimChannelText::DeleteKeyframe(int k)
{
    mKeyframes.erase(mKeyframes.begin() + k);
}


/*! \brief Set a keyframe at the current time.
 * \param str Text string
 * \param mirror Mirror status
 */
void CAnimChannelText::SetKeyframe(const std::wstring &str, bool mirror)
{
    // Create a keyframe object
    KeyframeText keyframe;
    keyframe.SetFrame(GetTimeline()->GetCurrentFrame());
    keyframe.SetText(str);
    keyframe.SetMirror(mirror);

    switch(GetInsertAction())
    {
    case Append:
        mKeyframes.push_back(keyframe);
        mKeyframe1 = (int)mKeyframes.size() - 1;
        break;

    case Replace:
        mKeyframes[mKeyframe1] = keyframe;
        break;

    case Insert:
        mKeyframes.insert(mKeyframes.begin() + mKeyframe1 + 1, keyframe);
        mKeyframe1++;
        break;
    }

}


/*! \brief Get the current text.
 * \returns The text at this point in time.
 */
std::wstring CAnimChannelText::GetText()
{
    // If no keyframes we just return zero
    if(mKeyframe1 < 0 && mKeyframe2 < 0)
        return L"";

    // If we only have one keyframe, return its value
    if(mKeyframe1 < 0)
        return mKeyframes[mKeyframe2].GetText();

    return mKeyframes[mKeyframe1].GetText();
}


/*! \brief Get the current mirror status.
 * \returns The mirror status at this point in time.
 */
bool CAnimChannelText::GetMirror()
{
    // If no keyframes we just return zero
    if(mKeyframe1 < 0 && mKeyframe2 < 0)
        return false;

    // If we only have one keyframe, return its value
    if(mKeyframe1 < 0)
        return mKeyframes[mKeyframe2].GetMirror();

    return mKeyframes[mKeyframe1].GetMirror();
}




/*! \brief Create an XML node that saves the animation channel
 * \returns The created XML node
 */
wxXmlNode *CAnimChannelText::XmlSave()
{
    wxXmlNode *root = CAnimChannel::XmlSave();

    root->AddAttribute(L"type", L"point");

    wxXmlNode *lastChild = NULL;
    for(std::vector<KeyframeText>::iterator f=mKeyframes.begin(); f!=mKeyframes.end();  f++)
    {
        // f in this case is a pointer to an actual keyframe and
        // does not need the two levels of indirection in this case.
        wxXmlNode *node = f->XmlSave();

        // If we have a previous child, add this node after
        // the child.
        if(lastChild == NULL)
        {
            root->AddChild(node);
        }
        else
        {
            lastChild->SetNext(node);
        }

        lastChild = node;
    }

    return root;
}



/*! \brief Save a keyframe to an xml node.
 * \returns The new keyframe node
 */
wxXmlNode *CAnimChannelText::KeyframeText::XmlSave()
{
    // Create a new node for the keyframe
    wxXmlNode *node = CAnimChannel::Keyframe::XmlSave();

    node->AddAttribute(L"text", mText.c_str());
    node->AddAttribute(L"mirror", mMirror ? L"yes" : L"no");

    return node;
}

/*! \brief Clear the point channel keyframes.
 */
void CAnimChannelText::Clear()
{
    CAnimChannel::Clear();
    mKeyframes.clear();
}


/*! \brief Load the XML node for a keyframe.
 * \param  node the XML node containing the keyframe data
 */
void CAnimChannelText::XmlLoad(wxXmlNode *node)
{
    // The form of the file is:
    //      <channel name="background:Background" type="angle">
    //        <keyframe frame="0" angle="0.000000"/>
    //        <keyframe frame="30" angle="0.000000"/>
    //      </channel>
    //      <channel name="Harold:position" type="point">
    //        <keyframe frame="0" x="400" y="500"/>
    //        <keyframe frame="30" x="533" y="425"/>
    //      </channel>
    // We are looping over the children of the channel tag

    wxXmlNode *child = node->GetChildren();
    while(child != NULL)
    {
        if(child->GetName() == L"keyframe")
        {
            // We have a keyframe node
            // Create a keyframe object
            KeyframeText keyframe;

            // Load it
            keyframe.XmlLoad(child);

            // And add to the list
            mKeyframes.push_back(keyframe);
        }

        child = child->GetNext();

    }

    // Do any base class finish-up
    CAnimChannel::XmlLoad(node);
}

/*! \brief Load the XML node for a keyframe.
 * \param node The XML node containing the keyframe data
 */
void CAnimChannelText::KeyframeText::XmlLoad(wxXmlNode *node)
{
    // Call the base class version
    CAnimChannel::Keyframe::XmlLoad(node);
    mText = node->GetAttribute(L"text", L"");
    std::wstring mirror = node->GetAttribute(L"mirror", L"no").wc_str();
    mMirror = mirror == L"yes";
}