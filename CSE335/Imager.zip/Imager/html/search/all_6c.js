var searchData=
[
  ['loadfile',['LoadFile',['../class_c_document.html#a121ea40421a0ed5c9f2024945ed88645',1,'CDocument::LoadFile()'],['../class_c_picture.html#a355e00ca5c19ccd55789e935c4efeef2',1,'CPicture::LoadFile()']]]
];
