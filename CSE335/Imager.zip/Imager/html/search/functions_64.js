var searchData=
[
  ['determinegradient',['DetermineGradient',['../class_c_base_canny.html#a221bc832858c8f0e274034e54db54132',1,'CBaseCanny::DetermineGradient()'],['../class_c_canny.html#a06559a05aa3f06160fd06d9ebb043c02',1,'CCanny::DetermineGradient()']]],
  ['draw',['Draw',['../class_c_document.html#a9d4c7fc45d51a5b906b81ee5d7c3be2a',1,'CDocument']]]
];
