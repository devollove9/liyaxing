var searchData=
[
  ['ids',['Ids',['../class_c_benchmark_dlg.html#ad9c75f24d03b4087d073d9f0ae2fcbb3',1,'CBenchmarkDlg::Ids()'],['../class_c_frame.html#a2be003f19321982a043ae5f0aea1daff',1,'CFrame::Ids()'],['../class_c_id_dlg.html#a16b3aec9c5aa4d1071e0b0e27ba10c02',1,'CIdDlg::Ids()'],['../class_c_moments_dlg.html#a1e7308e73dfc5a1b2692e70be183f145',1,'CMomentsDlg::Ids()'],['../class_c_processing_dlg.html#a0ae1c112326317852f81c4c3176c24e2',1,'CProcessingDlg::Ids()'],['../class_c_progress_ctrl.html#a1292ecb317ab5aca12985f8575ae0be5',1,'CProgressCtrl::Ids()'],['../class_c_test_dlg.html#ab02d98262e15422925539857f1317011',1,'CTestDlg::Ids()']]]
];
