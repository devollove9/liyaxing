var searchData=
[
  ['addobserver',['AddObserver',['../class_c_document.html#aa933d5775384cded0a1f967bd50bb46e',1,'CDocument']]],
  ['analyze',['Analyze',['../class_c_moments.html#a976522ddd9bbd901e6522a5f647ceef7',1,'CMoments']]]
];
