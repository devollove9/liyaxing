var searchData=
[
  ['validate',['Validate',['../class_c_picture.html#a99452f9a8f538080f390d8c2f039d0fb',1,'CPicture']]]
];
