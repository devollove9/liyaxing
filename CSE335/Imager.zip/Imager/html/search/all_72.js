var searchData=
[
  ['removeobserver',['RemoveObserver',['../class_c_document.html#a4ac181bee015c7aa00c4daf97c71b1e1',1,'CDocument']]]
];
