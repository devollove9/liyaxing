var searchData=
[
  ['directions',['Directions',['../class_c_base_canny.html#a3dbfeb7a0106ddd99a52989e383e634c',1,'CBaseCanny::Directions()'],['../class_c_canny.html#ad470c5336a9f3f0de337cd362faae823',1,'CCanny::Directions()']]]
];
