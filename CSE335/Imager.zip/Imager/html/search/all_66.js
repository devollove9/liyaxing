var searchData=
[
  ['fitzoom',['FitZoom',['../class_c_view_edit.html#a27fabc5d4cd58fe300ae9fbfcbed60a4',1,'CViewEdit']]]
];
