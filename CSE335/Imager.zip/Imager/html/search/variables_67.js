var searchData=
[
  ['gridspacing',['GridSpacing',['../class_c_city.html#a08cb723941e71de2c102d8ec50dbff8e',1,'CCity']]]
];
