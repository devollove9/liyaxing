var searchData=
[
  ['preparetoread',['PrepareToRead',['../class_c_picture.html#abe4e9ca535784bb84b27d15cae5edeaf',1,'CPicture']]],
  ['process',['Process',['../class_c_base_black_and_white.html#ac4ad42159c56daf87004e22a6866436a',1,'CBaseBlackAndWhite::Process()'],['../class_c_base_canny.html#afb6b929e6a99fe9c33b3afca9894a0c0',1,'CBaseCanny::Process()'],['../class_c_base_emboss.html#aa18393183b41ac9df5686e55c59e8a2e',1,'CBaseEmboss::Process()'],['../class_c_black_and_white.html#a787774c4d9700259f719e4b92e4997e1',1,'CBlackAndWhite::Process()'],['../class_c_canny.html#add0ebc7d19718b844a1e172477157fbe',1,'CCanny::Process()'],['../class_c_emboss.html#a3e00af3d113de739a18f602e36a22219',1,'CEmboss::Process()'],['../class_c_frame.html#add0ce45811bae84d7293703d8de82346',1,'CFrame::Process()'],['../class_c_processor.html#abbc9b6b4e1eff4a896448a3923ebe274',1,'CProcessor::Process()']]]
];
