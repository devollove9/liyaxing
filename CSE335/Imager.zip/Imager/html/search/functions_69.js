var searchData=
[
  ['issetblack',['IsSetBlack',['../class_c_processor.html#a5385658f6c075d12c2ebae867764e2bd',1,'CProcessor']]]
];
