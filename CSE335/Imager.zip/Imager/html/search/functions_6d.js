var searchData=
[
  ['moment',['Moment',['../class_c_moments.html#a5e86a006ccbecb0f39fbe4c54552f8c7',1,'CMoments']]]
];
