var searchData=
[
  ['trace',['Trace',['../class_c_base_canny.html#ac6dc8a6ee133c6b48cd78a6e0cca03ec',1,'CBaseCanny::Trace()'],['../class_c_canny.html#aaec66ead2b8bd1d3b5f8d7872c75dd00',1,'CCanny::Trace()']]],
  ['traceedges',['TraceEdges',['../class_c_base_canny.html#ad4da02b3279876c7c2299c71eb57b8bc',1,'CBaseCanny::TraceEdges()'],['../class_c_canny.html#aafbb4c91fde8c5da8a9e6ff43a90d645',1,'CCanny::TraceEdges()']]]
];
