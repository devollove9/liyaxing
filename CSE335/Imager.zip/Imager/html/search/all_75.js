var searchData=
[
  ['updateobserver',['UpdateObserver',['../class_c_document_observer.html#abaca6d65727ea6e3085ad5d44392a7d1',1,'CDocumentObserver::UpdateObserver()'],['../class_c_view_edit.html#ac553924335215f31e7dc93265512310a',1,'CViewEdit::UpdateObserver()']]],
  ['updateobservers',['UpdateObservers',['../class_c_document.html#a31cb493d457c8d1bb0ea48f2c62deccc',1,'CDocument']]]
];
