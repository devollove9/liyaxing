var searchData=
[
  ['name',['Name',['../class_c_base_black_and_white.html#a29547a489709654af15e9410f69b0a0d',1,'CBaseBlackAndWhite::Name()'],['../class_c_base_canny.html#a0de591342717b36f4a04fb87aacd5cff',1,'CBaseCanny::Name()'],['../class_c_base_emboss.html#a1dae0065abaf0dcda5c624ca102bb0d6',1,'CBaseEmboss::Name()'],['../class_c_black_and_white.html#ad1d433c3cf8139525c5632cbb6d3ee3f',1,'CBlackAndWhite::Name()'],['../class_c_canny.html#af413a707ff19fd44e1ba7fd11ea00dde',1,'CCanny::Name()'],['../class_c_emboss.html#adce39ad612515141ae42101266b791d3',1,'CEmboss::Name()'],['../class_c_processor.html#a190b0f3e23ece0a2b2a2d3f686afc452',1,'CProcessor::Name()']]],
  ['nonmaximumsuppression',['NonMaximumSuppression',['../class_c_base_canny.html#abc6d2668d7efa30f2513ffe8e5cb6cd5',1,'CBaseCanny::NonMaximumSuppression()'],['../class_c_canny.html#aa18f1458fb27f075fb31ab721309ef99',1,'CCanny::NonMaximumSuppression()']]]
];
