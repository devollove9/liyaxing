/** 
 * \file CSpeech.h
 * 
 * This is a dummy header file designed to allow for addition of
 * accessibility components to a project. It is replaced by a different
 * file to make a program speak.
 */

#ifndef CSPEECH_H
#define	CSPEECH_H

//#define CSPEECH

//#include <iostream>
//#define speak std::wcout 

#endif	/* CSPEECH_H */

